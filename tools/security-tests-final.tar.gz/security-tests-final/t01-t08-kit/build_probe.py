#!/usr/bin/env python3
import argparse, pathlib, subprocess, json, hashlib, os
p=argparse.ArgumentParser();p.add_argument('--sdk',required=True);p.add_argument('--library',required=True);p.add_argument('--compiler',default='g++');p.add_argument('--allow-other-commit',action='store_true');a=p.parse_args()
sdk=pathlib.Path(a.sdk).resolve(); lib=pathlib.Path(a.library).resolve();root=pathlib.Path(__file__).resolve().parent
commit=subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()
expected='5827665c7e0fe493c22b56a8a05eefc3023ec3b1'
if commit!=expected and not a.allow_other_commit: raise SystemExit('Wrong SDK commit; use separate checkout at '+expected+' or explicitly --allow-other-commit.')
if not lib.is_file():raise SystemExit('Library is not a regular file')
paths=['lib/internal','lib/include','lib/fabrics']
diff=subprocess.check_output(['git','-C',str(sdk),'diff','HEAD','--',*paths],text=True)
untracked=subprocess.check_output(['git','-C',str(sdk),'ls-files','--others','--exclude-standard','--',*paths],text=True)
(root/'sdk-source-diff.txt').write_text(diff);(root/'sdk-untracked-files.txt').write_text(untracked)
if diff:raise SystemExit('Tracked SDK-source/build-wiring differences found. Preserve them and resolve baseline before compiling. This script never resets your checkout.')
cmd=[a.compiler,'-std=c++20','-O2','-Wall','-Wextra','-I'+str(sdk/'lib/include'),str(root/'probe.cpp'),str(lib),'-Wl,-rpath,'+str(lib.parent),'-ldl','-pthread','-o',str(root/'probe')]
r=subprocess.run(cmd,text=True,capture_output=True);(root/'build.log').write_text(r.stdout+r.stderr)
if r.returncode:raise SystemExit('Probe compilation failed; see build.log. Resolve loader dependencies without changing SDK implementation.')
v=subprocess.run([str(root/'probe'),'version'],text=True,capture_output=True)
(root/'build-manifest.json').write_text(json.dumps({'commit':commit,'sdk':str(sdk),'library':str(lib),'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'probe_sha256':hashlib.sha256((root/'probe').read_bytes()).hexdigest(),'compiler_command':cmd,'compiler':subprocess.check_output([a.compiler,'--version'],text=True),'version_stdout':v.stdout,'version_stderr':v.stderr,'version_exit':v.returncode,'untracked_files':untracked},indent=2))
if v.returncode:raise SystemExit('Build completed, but probe cannot query SDK version. See manifest; fix runtime dependency resolution.')
print('Probe built; SDK untouched. '+v.stdout)
