#!/usr/bin/env python3
"""One selected experiment per invocation; observations are not exploit verdicts."""
import argparse, pathlib, subprocess, selectors, time, os, signal, json, tempfile, uuid, struct, hashlib, platform, resource
ROOT=pathlib.Path(__file__).resolve().parent
NAMES=['baseline','publication','writers','tamper','bounds','json','gc','null']
p=argparse.ArgumentParser();p.add_argument('test',choices=NAMES);p.add_argument('--iterations',type=int,default=1000);p.add_argument('--seed',type=int,default=31);p.add_argument('--umask',default='0002');p.add_argument('--seconds',type=int,default=120);a=p.parse_args()
if not 1<=a.iterations<=10000 or not 5<=a.seconds<=3600:raise SystemExit('Use iterations 1..10000 and seconds 5..3600')
probe=ROOT/'probe'
if not probe.exists():raise SystemExit('Run build_probe.py first')
os.umask(int(a.umask,8))
out=ROOT/'results'/(time.strftime('%Y%m%dT%H%M%S')+'-'+a.test+'-'+uuid.uuid4().hex[:6]);out.mkdir(parents=True)
domain=pathlib.Path(tempfile.mkdtemp(prefix='mxl-security-',dir='/dev/shm'));actors=[];events=[];deadline=time.monotonic()+a.seconds
# Enforced overall deadline in addition to per-operation deadlines.
def alarm(signum,frame):raise TimeoutError('overall deadline exceeded')
signal.signal(signal.SIGALRM,alarm);signal.alarm(a.seconds)
def ev(kind,**kw):
 row={'monotonic':time.monotonic(),'kind':kind,**kw};events.append(row)
 with (out/'events.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
def remaining():return max(0.01,min(8,deadline-time.monotonic()))
def fields(line):
 return {k:v for k,v in (part.split('=',1) for part in line.split() if '=' in part)}
class Actor:
 def __init__(self,mode,arg):
  self.name=f'{mode}-{len(actors)}';self.log=(out/(self.name+'.stdout')).open('w');self.err=(out/(self.name+'.stderr')).open('w')
  self.p=subprocess.Popen([str(probe),mode,str(domain),str(arg)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.err,bufsize=0,close_fds=True,start_new_session=True)
  self.buffer=b'';actors.append(self);ev('launch',name=self.name,pid=self.p.pid,mode=mode,arg=str(arg));self.ready=self.get()
 def get(self):
  sel=selectors.DefaultSelector();sel.register(self.p.stdout,selectors.EVENT_READ)
  end=time.monotonic()+remaining()
  try:
   while True:
    if b'\n' not in self.buffer:
     if not sel.select(max(0,end-time.monotonic())):raise TimeoutError(self.name+' operation timeout')
     chunk=os.read(self.p.stdout.fileno(),65536)
     if not chunk:raise RuntimeError(self.name+' exited: '+str(self.p.poll()))
     self.buffer+=chunk
     continue
    raw,self.buffer=self.buffer.split(b'\n',1);line=raw.decode(errors='replace')+'\n'
    self.log.write(line);self.log.flush()
    if line.startswith('RESULT '):ev('result',actor=self.name,line=line.strip());return fields(line)
    if time.monotonic()>end:raise TimeoutError(self.name+' no RESULT')
  finally:sel.close()
 def send(self,s):ev('command',actor=self.name,command=s);self.p.stdin.write((s+'\n').encode());self.p.stdin.flush()
 def call(self,s):self.send(s);return self.get()
 def stop(self):
  if self.p.poll() is None:
   os.killpg(self.p.pid,signal.SIGTERM)
   try:self.p.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(self.p.pid,signal.SIGKILL);self.p.wait()
  ev('exit',actor=self.name,returncode=self.p.returncode);self.log.close();self.err.close()
def need(row,key,value='0'):
 if row.get(key)!=str(value):raise RuntimeError(f'Prerequisite/operation failed: {key} expected {value}; {row}')
def fixture(label='control',extra=None):
 fid=str(uuid.uuid4());d={'id':fid,'format':'urn:x-nmos:format:video','label':label,'description':'Disposable security test','tags':{'urn:x-nmos:tag:grouphint/v1.0':['Chris Lapp test:Video']},'parents':[],'media_type':'video/v210','grain_rate':{'numerator':25,'denominator':1},'frame_width':48,'frame_height':8,'interlace_mode':'progressive','colorspace':'BT709','components':[{'name':'Y','width':48,'height':8,'bit_depth':10},{'name':'Cb','width':24,'height':8,'bit_depth':10},{'name':'Cr','width':24,'height':8,'bit_depth':10}]}
 if extra:d.update(extra)
 f=out/(fid+'.json');f.write_text(json.dumps(d));return fid,f

def write(w,i=0,seed=a.seed):
 z=w.call(f'WRITE {i} {seed} 0');need(z,'open');need(z,'commit');return int(z['size'])
def read(r,i,size,seed=a.seed):return r.call(f'READ {i} {seed} 1000000000 {size}')
def checkread(z,i,size):
 need(z,'read');need(z,'index',i);need(z,'size',size);need(z,'checked',size);need(z,'bad',0)
def inventory():
 rows=[]
 for f in domain.rglob('*'):
  st=f.lstat();rows.append({'path':str(f),'mode':oct(st.st_mode&0o7777),'uid':st.st_uid,'gid':st.st_gid,'inode':st.st_ino,'size':st.st_size})
 (out/'file-inventory.json').write_text(json.dumps(rows,indent=2))
def bounded():
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(5,5));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
summary={'test':a.test,'state':'INCONCLUSIVE','domain':str(domain),'evidence':str(out),'platform':platform.platform(),'machine':platform.machine(),'uid':os.geteuid(),'gid':os.getegid(),'groups':os.getgroups(),'umask':a.umask,'iterations_requested':a.iterations,'seed':a.seed,'baseline_commit':'5827665c7e0fe493c22b56a8a05eefc3023ec3b1','not_an_exploit_verdict':True}
try:
 if not (ROOT/'build-manifest.json').exists():raise RuntimeError('Missing build manifest')
 summary['build']=json.loads((ROOT/'build-manifest.json').read_text())
 manifest=summary['build']
 for file,key in [(probe,'probe_sha256'),(pathlib.Path(manifest['library']),'library_sha256')]:
  if hashlib.sha256(file.read_bytes()).hexdigest()!=manifest[key]:raise RuntimeError('Binary changed since build: '+str(file))
 v=subprocess.run([str(probe),'version'],capture_output=True,text=True,timeout=8)
 summary['run_version_stdout']=v.stdout;summary['run_version_stderr']=v.stderr
 if v.returncode:raise RuntimeError('SDK version query failed')
 loaded=fields(next((line for line in v.stdout.splitlines() if line.startswith('RESULT ')),'' )).get('library')
 if not loaded or pathlib.Path(loaded).resolve()!=pathlib.Path(manifest['library']).resolve():raise RuntimeError('Loaded library differs from manifest')

 # Fixture and ordinary API control required before every experiment.
 fid,f=fixture();w=Actor('writer',f);need(w.ready,'create');need(w.ready,'created',1)
 size=write(w);r=Actor('reader',fid);need(r.ready,'reader');checkread(read(r,0,size),0,size);ev('baseline_validated',size=size,ring=w.ready.get('ring'))
 if a.test=='baseline':summary.update(state='CONTROL_PASSED',payload_bytes=size)
 elif a.test=='publication':
  ring=int(w.ready['ring']);count=max(a.iterations,ring*2+1)
  if count>10000:raise RuntimeError('Ring too large for bounded wraparound run')
  for i in range(1,count+1):
   r.send(f'READ {i} {a.seed} 1000000000 {size}')
   write(w,i);z=r.get();checkread(z,i,size)
  summary.update(state='NO_FAILURE_OBSERVED',validated=count,ring=ring,wraparounds=count//ring,limitation='One outstanding grain; acknowledgment avoids overwrite. Discrete flows only. No general race-freedom claim.')
 elif a.test=='writers':
  # Separate no-contention control was already established above.
  w2=Actor('writer',f)
  if 'create' not in w2.ready:raise RuntimeError('Second writer instance failed before creation attempt')
  if w2.ready.get('create')!='0':summary.update(state='ADDITIONAL_WRITER_REJECTED_THIS_CASE',second_writer=w2.ready)
  else:
   # Serial control: second writer can commit and reader sees its pattern.
   need(w2.ready,'created',0);write(w2,1,77);checkread(read(r,1,size,77),1,size)
   observed=[]
   for i in range(2,min(a.iterations,1000)+2):
    # Both commands dispatched before collecting outcomes. Both are valid calls;
    # same-grain writes intentionally collide, which is not a single-writer race test.
    w.send(f'WRITE {i} 31 50');w2.send(f'WRITE {i} 77 50')
    z1=w.get();z2=w2.get();need(z1,'open');need(z1,'commit');need(z2,'open');need(z2,'commit')
    q1=read(r,i,size,31);q2=read(r,i,size,77);need(q1,'read');need(q2,'read')
    mixed=int(q1['bad'])>0 and int(q2['bad'])>0
    observed.append({'index':i,'not_writer1_bytes':int(q1['bad']),'not_writer2_bytes':int(q2['bad']),'mixed':mixed})
   summary.update(state='ADDITIONAL_WRITER_ACCEPTED',overlap_dispatch=True,interleaving_not_guaranteed=True,mixed_grains=sum(x['mixed'] for x in observed),consumer_observations=observed,limitation='Requires an explicitly stated exclusive-writer policy before calling acceptance a security violation. Mixed output does not establish a single-writer publication bug.')
 elif a.test in ('tamper','bounds'):
  # Pinned on-disk layout; never apply these offsets to another commit.
  if summary.get('build',{}).get('commit')!=summary['baseline_commit']:raise RuntimeError('On-disk mutation requires exact pinned commit')
  target=domain/(fid+'.mxl-flow')/'grains'/'data.0'
  if not target.is_file() or target.stat().st_size < 8192+size:raise RuntimeError('Pinned grain layout not found')
  layout=subprocess.check_output([str(probe),'layout'],text=True);(out/'layout.txt').write_text(layout);offs=fields(layout)
  if a.test=='tamper':
   with target.open('r+b') as q:q.seek(8192);original=q.read(4);q.seek(8192);q.write(bytes.fromhex('deadbeef'));q.flush()
   z=read(r,0,size);need(z,'read');need(z,'checked',size)
   summary.update(state='TAMPERING_RETURNED' if int(z['bad'])>0 else 'NO_CHANGED_BYTES_OBSERVED',read=z,write_identity=os.geteuid(),limitation='Same-UID direct file write; no authorization bypass. Exactly four bytes changed.')
  else:
   cases=[('grainSize',0,4),('grainSize',size+1,4),('grainSize',0xffffffff,4),('totalSlices',0,2),('validSlices',0,2),('validSlices',65535,2)]
   rows=[]
   for name,value,width in cases:
    off=int(offs[name])
    with target.open('r+b') as q:q.seek(off);old=q.read(width);q.seek(off);q.write(value.to_bytes(width,'little'));q.flush()
    try:
     # Isolated fresh executable reader for each mutated value, no unsafe consumer copy.
     child=Actor('reader',fid);need(child.ready,'reader');z=read(child,0,size)
     rows.append({'field':name,'value':value,'returned':z});child.stop()
    except Exception as e:rows.append({'field':name,'value':value,'error':str(e)})
    finally:
     with target.open('r+b') as q:q.seek(off);q.write(old);q.flush()
    checkread(read(r,0,size),0,size)
   summary.update(state='BOUNDS_OBSERVATIONS_RECORDED',cases=rows,limitation='No access beyond known-good payload capacity. Accepted oversized metadata is not proof of out-of-bounds access in SDK or a named consumer.')
 elif a.test=='json':
  rows=[]
  inputs=[('malformed','{'),('zero_denominator',json.dumps({**json.loads(f.read_text()),'id':str(uuid.uuid4()),'grain_rate':{'numerator':25,'denominator':0}}))]
  for n in [1024,65536,1048576,4194304]:
   d=json.loads(f.read_text());d['id']=str(uuid.uuid4());d['description']='x'*n;inputs.append(('string_'+str(n),json.dumps(d)))
  for depth in [16,64,128,256]:
   d=json.loads(f.read_text());d['id']=str(uuid.uuid4());base=json.dumps(d)[:-1];inputs.append(('depth_'+str(depth),base+',"test_extension":'+('['*depth)+'0'+(']'*depth)+'}'))
  for label,data in inputs:
   path=out/(label+'.json');path.write_text(data);t=time.monotonic()
   with (out/(label+'.stdout')).open('w') as so,(out/(label+'.stderr')).open('w') as se:
    try:proc=subprocess.run([str(probe),'create',str(domain),str(path)],stdout=so,stderr=se,timeout=8,close_fds=True,start_new_session=True,preexec_fn=bounded);code=proc.returncode
    except subprocess.TimeoutExpired:code='timeout'
   rows.append({'case':label,'bytes':len(data.encode()),'seconds':time.monotonic()-t,'exit':code})
  summary.update(state='JSON_OBSERVATIONS_RECORDED',cases=rows,limitation='1 GiB address-space/5-second CPU limits are external controls; termination at those limits is not an unbounded SDK exhaustion result. No downstream zero-denominator safety claim.')
 elif a.test=='gc':
  os.kill(w.p.pid,signal.SIGSTOP)
  try:
   g=subprocess.run([str(probe),'gc',str(domain),'unused'],capture_output=True,text=True,timeout=8);ev('gc_while_paused',exit=g.returncode,stdout=g.stdout,stderr=g.stderr)
   if g.returncode!=0:raise RuntimeError('GC control failed')
  finally:os.kill(w.p.pid,signal.SIGCONT)
  write(w,1);checkread(read(r,1,size),1,size)
  summary.update(state='PAUSED_FLOW_PRESERVED_AND_RESUMED',limitation='Reader also remained open; this proves active flow preservation for this configuration, not writer-only retention.')
 elif a.test=='null':
  with (out/'null.stdout').open('w') as so,(out/'null.stderr').open('w') as se:
   proc=subprocess.run([str(probe),'null'],stdout=so,stderr=se,timeout=8,preexec_fn=bounded,close_fds=True)
  summary.update(state='SIGNAL_OBSERVED' if proc.returncode<0 else 'NO_SIGNAL_OBSERVED',returncode=proc.returncode,signal=-proc.returncode if proc.returncode<0 else None,limitation='Caller supplies null directly. No attacker-controlled service path or root cause backtrace established.')
except Exception as e:summary['error']=str(e);ev('exception',error=str(e))
finally:
 signal.alarm(0)
 inventory()
 for actor in actors:
  actor.stop()
 # Keep unique disposable domain for inspection, never remove production paths.
 (out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
print('Evidence:',out);print('Disposable domain retained:',domain)
raise SystemExit(2 if summary['state']=='INCONCLUSIVE' else 0)
