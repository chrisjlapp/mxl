// Test harness by Chris Lapp; SDK implementation is not modified.
#include <mxl/flow.h>
#include <mxl/mxl.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <cstring>
#include <string>
#include <unistd.h>
#include <dlfcn.h>
#include <cstddef>
#include <stdexcept>

static void result(std::string const& s) { std::cout << "RESULT " << s << std::endl; }
static unsigned char pattern(uint64_t index, size_t offset, unsigned seed) {
    return (unsigned char)((index * 17 + offset * 31 + seed) & 255);
}
int main(int argc,char** argv) {
    std::cout.setf(std::ios::unitbuf);
    if(argc < 2) return 2;
    std::string mode=argv[1];
    if(mode=="version") {
        mxlVersionType v{}; auto s=mxlGetVersion(&v); Dl_info di{};
        dladdr(reinterpret_cast<void*>(&mxlCreateInstance), &di);
        result("status="+std::to_string(s)+" version="+(v.full?v.full:"")+" library="+(di.dli_fname?di.dli_fname:"")); return s==0?0:3;
    }
    if(mode=="layout") {
        result("grainSize="+std::to_string(offsetof(mxlGrainInfo,grainSize))+" totalSlices="+std::to_string(offsetof(mxlGrainInfo,totalSlices))+" validSlices="+std::to_string(offsetof(mxlGrainInfo,validSlices))+" headerInfoSize="+std::to_string(sizeof(mxlGrainInfo)));return 0;
    }
    if(mode=="null") { auto i=mxlCreateInstance(nullptr,"{}"); result("instance="+std::to_string(i!=nullptr)); if(i)mxlDestroyInstance(i);return 0; }
    if(argc<4) return 2;
    auto inst=mxlCreateInstance(argv[2],"{}");
    if(!inst) { result("instance=0"); return 3; }
    if(mode=="gc") {auto s=mxlGarbageCollectFlows(inst);result("gc="+std::to_string(s));mxlDestroyInstance(inst);return s==0?0:3;}
    mxlFlowWriter w{}; mxlFlowReader r{}; mxlFlowConfigInfo config{};
    mxlStatus setup;
    if(mode=="writer" || mode=="create") {
        std::ifstream f(argv[3]);std::stringstream b;b<<f.rdbuf();if(!f){result("fixture=missing");mxlDestroyInstance(inst);return 2;}
        bool created=false;setup=mxlCreateFlowWriter(inst,b.str().c_str(),nullptr,&w,&config,&created);
        result("create="+std::to_string(setup)+" created="+std::to_string(created)+" pid="+std::to_string(getpid())+" uid="+std::to_string(geteuid())+" gid="+std::to_string(getegid())+" ring="+std::to_string(setup==0?config.discrete.grainCount:0));
        if(mode=="create" || setup!=0){if(w)mxlReleaseFlowWriter(inst,w);mxlDestroyInstance(inst);return setup==0?0:3;}
    } else if(mode=="reader") {
        setup=mxlCreateFlowReader(inst,argv[3],nullptr,&r);
        result("reader="+std::to_string(setup)+" pid="+std::to_string(getpid())+" uid="+std::to_string(geteuid())+" gid="+std::to_string(getegid()));
        if(setup!=0){mxlDestroyInstance(inst);return 3;}
    } else {mxlDestroyInstance(inst);return 2;}
    std::string line;
    while(std::getline(std::cin,line)) {
        std::istringstream in(line);std::string cmd;uint64_t index=0;unsigned seed=0;in>>cmd;
        if(cmd=="QUIT")break;
        if(cmd=="WRITE" && w) {
            in>>index>>seed; unsigned delay=0;in>>delay;
            mxlGrainInfo g{};uint8_t* p=nullptr;auto s=mxlFlowWriterOpenGrain(w,index,&g,&p);
            auto size=g.grainSize;
            if(s!=0 || !p || size==0 || size>16*1024*1024) {result("open="+std::to_string(s)+" invalid_payload=1");continue;}
            for(size_t k=0;k<size;k++){p[k]=pattern(index,k,seed);if(delay && k%4096==0)usleep(delay);}
            g.validSlices=g.totalSlices;
            auto c=mxlFlowWriterCommitGrain(w,&g);
            result("open="+std::to_string(s)+" commit="+std::to_string(c)+" index="+std::to_string(index)+" size="+std::to_string(size)+" total="+std::to_string(g.totalSlices));
        } else if(cmd=="READ" && r) {
            in>>index>>seed;uint64_t timeout=1000000000ULL;in>>timeout;
            mxlGrainInfo g{};uint8_t* p=nullptr;auto s=mxlFlowReaderGetGrain(r,index,timeout,&g,&p);
            // Never trust a mutated grainSize to define how far the harness reads.
            uint64_t expected=0;in>>expected;
            size_t checked=0,bad=0;
            if(s==0 && p && expected>0 && expected<=16*1024*1024 && g.grainSize==expected) {
                checked=expected;for(size_t k=0;k<checked;k++)if(p[k]!=pattern(index,k,seed))++bad;
            }
            result("read="+std::to_string(s)+" index="+std::to_string(g.index)+" size="+std::to_string(g.grainSize)+" total="+std::to_string(g.totalSlices)+" valid="+std::to_string(g.validSlices)+" checked="+std::to_string(checked)+" bad="+std::to_string(bad));
        } else {result("command=invalid");}
    }
    if(w)result("releaseWriter="+std::to_string(mxlReleaseFlowWriter(inst,w)));
    if(r)result("releaseReader="+std::to_string(mxlReleaseFlowReader(inst,r)));
    result("destroy="+std::to_string(mxlDestroyInstance(inst)));return 0;
}
