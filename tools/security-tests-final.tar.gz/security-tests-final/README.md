# Final-experiment test assets

Collected 16 Oct 2026. Contains the test sources, helpers and binaries used by the FINAL
executions behind MXL Security Report v1.17 — not the run evidence (that lives in the
per-campaign archives referenced below). SDK implementation code is not included; see
the provenance files for commit and patch linkage.

| directory | powers | evidence archive |
|---|---|---|
| host-integration-suite/ | A–F integration suite (paper §5 tables; includes crash and C3 helpers, flow fixtures) | S3/S4 (mxl-security-test-kit era) |
| t01-t08-kit/ | T01–T08 local SDK experiments | S6 mxl-security-test-kit-bundle |
| c-nr01-container/ | C-NR-01 non-root container experiments (vC orchestrator 7ea9c279…, actor 2d7d43b7…, probe 6e5caa0e…; recovered vA/vB/v0 versions) | S15 cnr01-evidence-final.tar.gz (713d021a…) |
| v14-reference/ | V14 verbs delivery milestone harness (source identical to archived 4e7dd448…) | S16 mxl-v14-results.tar.gz |
| v15-fabric/ | V15/V15b/V15c: single-process control, role-split harness (current roles 14eb7f48…, sources with all disclosed fixes), T16/T17 orchestrators, corrected T18 script, aggregators, provenance | S17/S18/S19 mxl-fabric-security-v15.tar.gz (dc359672…) |
| fixtures/ | target flow definition (matches the V14-archived copy byte-for-byte) | — |

Note on binary versions: v15-roles here is the post-correction build used by executions
4–6 of the T17-B campaign; the binaries that ran the ORIGINAL V15 campaign (T16-A/B/C,
T17-A, T18) are hash-recorded in the archive (d172e54/9b2d4a5 lineage). Role changes were
orchestration/observability only; SDK call paths are unchanged — see
provenance-fabric.json source_state_note.
