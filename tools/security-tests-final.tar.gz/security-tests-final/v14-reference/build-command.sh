gcc -o /tmp/mxl-v14-verbs /tmp/mxl-v14-verbs.c \
  -I/home/chlapp/projects/mxl-security-baseline/lib/include \
  -I/home/chlapp/projects/mxl-security-baseline/lib/fabrics/include \
  -I/home/chlapp/projects/mxl-security-baseline/build/include \
  -L/home/chlapp/projects/mxl-security-baseline/build/lib \
  -L/home/chlapp/projects/mxl-security-baseline/build/lib/fabrics/ofi \
  -lmxl -lmxl-fabrics -lstdc++
# run with LD_LIBRARY_PATH=/opt/libfabric121/lib:build/lib:build/lib/fabrics/ofi
