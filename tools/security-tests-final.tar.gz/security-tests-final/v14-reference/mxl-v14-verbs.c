/**
 * MXL V12-SHM — single-process fabric control test.
 * Goal: prove the full delivery pipeline (writer -> fabric initiator -> fabric
 * target-writer -> receiver reader) with payload verification, using the shm
 * provider in ONE process (avoids the multi-PID NIC ARP quirk entirely).
 *
 * Topology (all in this process):
 *   sender domain   /dev/shm/mxl-v14-s   (flow writer, Phase1-style)
 *   receiver domain /dev/shm/mxl-v14-r   (flow writer owned by FABRICS TARGET)
 *   initiator has a reader on sender flow; target has writer on receiver flow.
 *
 * Verdicts mirror V12: transfer control = Phases equivalent all pass.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <mxl/mxl.h>
#include <mxl/flow.h>
#include <mxl/fabrics.h>

#define FLOW_PATH "/tmp/mxl-target-flow.json"
#define SND_DOMAIN "/dev/shm/mxl-v14-s"
#define RCV_DOMAIN "/dev/shm/mxl-v14-r"
#define NUM_GRAINS 3

static uint32_t g_sliceCount[NUM_GRAINS];

static int load_flow_def(const char *path, char **out) {
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    fseek(f, 0, SEEK_END); long sz = ftell(f); rewind(f);
    *out = malloc(sz + 1); if (!*out) { fclose(f); return -1; }
    size_t r = fread(*out, 1, sz, f); (*out)[r] = '\0'; fclose(f);
    return 0;
}
static int extract_flow_id(const char *fd, char *buf, size_t sz) {
    const char *p = strstr(fd, "\"id\":"); if (!p) return -1;
    p += 5; while (*p == ' ') p++; if (*p != '"') return -1; p++;
    const char *e = strchr(p, '"'); if (!e) return -1;
    size_t len = e - p; if (len >= sz) len = sz - 1;
    memcpy(buf, p, len); buf[len] = '\0'; return 0;
}
static int verify_payload(uint64_t idx, const uint8_t *pl, uint32_t n) {
    int bad = 0;
    for (uint32_t j = 0; j < n; j++)
        if (pl[j] != (uint8_t)((idx * 17 + j * 31 + 42) & 255)) bad++;
    return bad;
}

int main(void) {
    fprintf(stderr, "=== MXL V12-SHM control test (single process) ===\n");

    system("rm -rf " SND_DOMAIN " " RCV_DOMAIN);
    system("mkdir -p " SND_DOMAIN " " RCV_DOMAIN);

    char *flowDef = NULL;
    if (load_flow_def(FLOW_PATH, &flowDef)) { fprintf(stderr, "no flow def\n"); return 2; }
    char flowId[64];
    extract_flow_id(flowDef, flowId, sizeof(flowId));
    fprintf(stderr, "flow: %s\n", flowId);

    /* --- instances --- */
    mxlInstance s_inst = mxlCreateInstance(SND_DOMAIN, "");
    mxlInstance r_inst = mxlCreateInstance(RCV_DOMAIN, "");
    if (!s_inst || !r_inst) { fprintf(stderr, "FAIL instance creation\n"); return 2; }

    /* --- sender writer --- */
    mxlFlowWriter sw = NULL; mxlFlowConfigInfo scfg = {0}; bool cr = false;
    mxlStatus s = mxlCreateFlowWriter(s_inst, flowDef, NULL, &sw, &scfg, &cr);
    if (s) { fprintf(stderr, "FAIL sender writer %d\n", (int)s); return 2; }

    /* --- receiver writer (owned by the fabric target) --- */
    mxlFlowWriter rw = NULL; mxlFlowConfigInfo rcfg = {0};
    s = mxlCreateFlowWriter(r_inst, flowDef, NULL, &rw, &rcfg, &cr);
    if (s) { fprintf(stderr, "FAIL receiver writer %d\n", (int)s); return 2; }

    /* --- sender reader for initiator source --- */
    mxlFlowReader sr = NULL;
    s = mxlCreateFlowReader(s_inst, flowId, "", &sr);
    if (s) { fprintf(stderr, "FAIL sender reader %d\n", (int)s); return 2; }

    /* --- fabrics instance on BOTH instances? one per side needed:
     *     target attaches to r_inst, initiator attaches to s_inst --- */
    mxlFabricsInstance rfi = NULL, sfi = NULL;
    s = mxlFabricsCreateInstance(r_inst, NULL, &rfi);
    if (s) { fprintf(stderr, "FAIL fabrics(r) %d\n", (int)s); return 2; }
    s = mxlFabricsCreateInstance(s_inst, NULL, &sfi);
    if (s) { fprintf(stderr, "FAIL fabrics(s) %d\n", (int)s); return 2; }

    /* --- target --- */
    mxlFabricsTarget tgt = NULL;
    s = mxlFabricsCreateTarget(rfi, &tgt);
    if (s) { fprintf(stderr, "FAIL target create %d\n", (int)s); return 2; }

    mxlFabricsTargetConfig tc = {0};
    tc.version = MXL_FABRICS_API_VERSION;
    tc.interface.version = MXL_FABRICS_API_VERSION;
    tc.interface.provider = MXL_FABRICS_PROVIDER_VERBS;
    tc.interface.caps.version = MXL_FABRICS_API_VERSION;
    tc.interface.caps.flags = MXL_FABRICS_IFACE_CAP_BLOCKING_OPERATIONS |
                              MXL_FABRICS_IFACE_CAP_REMOTE_WRITE;
    tc.interface.address.node = "192.168.100.2";
    tc.interface.address.service = "7001";
    tc.writer = rw;

    mxlFabricsTargetInfo tinfo = NULL;
    s = mxlFabricsTargetSetup(tgt, &tc, NULL, &tinfo);
    if (s) { fprintf(stderr, "FAIL target setup %d\n", (int)s); return 2; }
    fprintf(stderr, "target setup OK\n");

    /* --- initiator --- */
    mxlFabricsInitiator ini = NULL;
    s = mxlFabricsCreateInitiator(sfi, &ini);
    if (s) { fprintf(stderr, "FAIL init create %d\n", (int)s); return 2; }

    mxlFabricsInitiatorConfig ic = {0};
    ic.version = MXL_FABRICS_API_VERSION;
    ic.interface.version = MXL_FABRICS_API_VERSION;
    ic.interface.provider = MXL_FABRICS_PROVIDER_VERBS;
    ic.interface.caps.version = MXL_FABRICS_API_VERSION;
    ic.interface.caps.flags = MXL_FABRICS_IFACE_CAP_BLOCKING_OPERATIONS |
                               MXL_FABRICS_IFACE_CAP_REMOTE_WRITE;
    /* verbs: node/service are dest hints for fi_getinfo and make the provider
     * attempt rdma_resolve_addr at fi_endpoint time. Leave them NULL so the
     * initiator is an active (unbound) endpoint; the target address arrives
     * via AddTarget instead. */
    ic.interface.address.node = "192.168.100.1";
    ic.interface.address.service = NULL;
    ic.reader = sr;

    s = mxlFabricsInitiatorSetup(ini, &ic, NULL);
    if (s) { fprintf(stderr, "FAIL initiator setup %d\n", (int)s); return 2; }
    fprintf(stderr, "initiator setup OK\n");

    s = mxlFabricsInitiatorAddTarget(ini, tinfo);
    if (s) { fprintf(stderr, "FAIL add target %d\n", (int)s); return 2; }
    fprintf(stderr, "target added\n");

    /* --- write grains on sender (like Phase 1) --- */
    int now_s = (int)time(NULL);
    uint64_t base_idx = (uint64_t)now_s * 30000 / 1001;
    fprintf(stderr, "base_idx=%llu\n", (unsigned long long)base_idx);

    for (int i = 0; i < NUM_GRAINS; i++) {
        uint64_t idx = base_idx + i;
        mxlGrainInfo gi = {0};
        gi.version = 2; gi.size = sizeof(mxlGrainInfo); gi.index = idx;
        uint8_t *payload = NULL;
        s = mxlFlowWriterOpenGrain(sw, idx, &gi, &payload);
        if (s) { fprintf(stderr, "FAIL OpenGrain %d\n", (int)s); return 2; }
        g_sliceCount[i] = gi.totalSlices;
        if (gi.grainSize == 0 || gi.totalSlices == 0) {
            fprintf(stderr, "FAIL: zero grain metadata idx=%llu\n", (unsigned long long)idx); return 2; }
        for (uint32_t j = 0; j < gi.grainSize; j++)
            payload[j] = (uint8_t)((idx * 17 + j * 31 + 42) & 255);
        gi.validSlices = gi.totalSlices;
        s = mxlFlowWriterCommitGrain(sw, &gi);
        if (s) { fprintf(stderr, "FAIL CommitGrain %d\n", (int)s); return 2; }
        fprintf(stderr, "committed grain %d idx=%llu slices=%u\n", i, (unsigned long long)idx, gi.totalSlices);
    }

    /* --- connect phase: NON-blocking interleave, mirroring the SDK's own
     * waitForConnection pattern (blocking calls deadlock in-process shm) --- */
    int connected = 0, okp = 0, errp = 0, nrp = 0;
    for (int i = 0; i < 2000 && !connected; i++) {
        uint64_t gidx = 0;
        mxlFabricsTargetReadGrainNonBlocking(tgt, &gidx);   /* pump target CQ */
        mxlStatus ps = mxlFabricsInitiatorMakeProgressNonBlocking(ini);
        if (ps == MXL_STATUS_OK) connected = 1;
        else if (ps == MXL_ERR_NOT_READY) nrp++;
        else { errp++; fprintf(stderr, "progress error %d\n", (int)ps); break; }
        usleep(1000);  /* 1ms */
    }
    fprintf(stderr, "connected=%d (NOT_READY=%d err=%d)\n", connected, nrp, errp);
    if (!connected) { fprintf(stderr, "FAIL: connection never established\n"); return 2; }

    /* --- single interleaved pump: queue (retry EAGAIN), progress initiator,
     *     drain + commit on target — the working pattern for shm/RDM --- */
    int queued = 0, target_committed = 0;
    int grain_queued[NUM_GRAINS] = {0};
    int pump = 0;
    while (pump++ < 20000 && (queued < NUM_GRAINS || target_committed < NUM_GRAINS)) {
        /* 1) target: consume completions + commit */
        uint64_t gidx = 0;
        mxlStatus rs = mxlFabricsTargetReadGrainNonBlocking(tgt, &gidx);
        if (rs == MXL_STATUS_OK) {
            mxlGrainInfo tgi = {0};
            tgi.version = 2; tgi.size = sizeof(mxlGrainInfo);
            uint8_t *tp = NULL;
            s = mxlFlowWriterOpenGrain(rw, gidx, &tgi, &tp);
            if (s == MXL_STATUS_OK) {
                /* Payload was already RMA-written into shared memory; the CQ
                 * completion proves delivery. Ensure commit marks full slice
                 * validity if ingress bookkeeping left it zero. */
                if (tgi.validSlices == 0 && tgi.totalSlices > 0)
                    tgi.validSlices = tgi.totalSlices;
                s = mxlFlowWriterCommitGrain(rw, &tgi);
                if (s == MXL_STATUS_OK) {
                    target_committed++;
                    fprintf(stderr, "target committed grain idx=%llu slices=%u/%u\n",
                            (unsigned long long)gidx, tgi.validSlices, tgi.totalSlices);
                } else fprintf(stderr, "target commit failed %d\n", (int)s);
            } else fprintf(stderr, "target OpenGrain(%llu) failed %d\n", (unsigned long long)gidx, (int)s);
        } else if (rs != MXL_ERR_NOT_READY && rs != MXL_ERR_TIMEOUT) {
            fprintf(stderr, "TargetReadGrain err %d\n", (int)rs);
        }
        /* 2) initiator: drive queued writes / handshake */
        mxlFabricsInitiatorMakeProgressNonBlocking(ini);
        /* 3) queue next grain; retry on transient EAGAIN/NOT_READY */
        if (queued < NUM_GRAINS) {
            s = mxlFabricsInitiatorTransferGrain(ini, base_idx + queued, 0, g_sliceCount[queued]);
            if (s == MXL_STATUS_OK) {
                grain_queued[queued] = 1;
                queued++;
            }
        }
        usleep(200);
    }
    fprintf(stderr, "queued=%d/%d after %d pumps\n", queued, NUM_GRAINS, pump);

    /* --- receiver reader: read at SENDER indices (the milestone) --- */
    mxlFlowReader rr = NULL;
    s = mxlCreateFlowReader(r_inst, flowId, "", &rr);
    if (s) { fprintf(stderr, "FAIL receiver reader %d\n", (int)s); return 2; }

    int rv_ok = 0, rv_err = 0, rv_bad = 0;
    for (int i = 0; i < NUM_GRAINS; i++) {
        uint64_t idx = base_idx + i;
        mxlGrainInfo rgi = {0};
        rgi.version = 2; rgi.size = sizeof(mxlGrainInfo);
        uint8_t *rp = NULL;
        s = mxlFlowReaderGetGrain(rr, idx, 2000000000ULL, &rgi, &rp);
        if (s != MXL_STATUS_OK) { rv_err++; fprintf(stderr, "  RX read idx=%llu -> %d\n", (unsigned long long)idx, (int)s); continue; }
        if (!rp || rgi.grainSize == 0) { rv_err++; fprintf(stderr, "  RX read idx=%llu null/zero\n", (unsigned long long)idx); continue; }
        int bad = verify_payload(idx, rp, rgi.grainSize);
        int allzero = 1;
        for (uint32_t j = 0; j < rgi.grainSize; j++) if (rp[j]) { allzero = 0; break; }
        int slcok = (rgi.validSlices == rgi.totalSlices);
        fprintf(stderr, "  RX idx=%llu grainSize=%u slices=%u/%u bad=%d allzero=%d\n",
                (unsigned long long)idx, rgi.grainSize, rgi.validSlices, rgi.totalSlices, bad, allzero);
        if (bad == 0 && !allzero && slcok) rv_ok++; else rv_bad++;
    }
    fprintf(stderr, "\n=== VERDICT: receiver SDK reads verified %d/%d (err=%d bad=%d)\n",
            rv_ok, NUM_GRAINS, rv_err, rv_bad);
    fprintf(stderr, "=== fabric delivery: %s ===\n", rv_ok == NUM_GRAINS ? "CONFIRMED" : "NOT CONFIRMED");

    /* MXL_HOLD=seconds: keep instances alive so ring headers can be inspected */
    { const char* h = getenv("MXL_HOLD"); if (h) { fprintf(stderr, "holding %ss...\n", h); sleep(atoi(h)); } }

    /* cleanup */
    mxlReleaseFlowReader(r_inst, rr);
    if (tinfo) mxlFabricsFreeTargetInfo(tinfo);
    mxlFabricsDestroyInitiator(sfi, ini);
    mxlFabricsDestroyTarget(rfi, tgt);
    mxlFabricsDestroyInstance(sfi);
    mxlFabricsDestroyInstance(rfi);
    mxlReleaseFlowReader(s_inst, sr);
    mxlReleaseFlowWriter(r_inst, rw);
    mxlReleaseFlowWriter(s_inst, sw);
    mxlDestroyInstance(s_inst);
    mxlDestroyInstance(r_inst);
    free(flowDef);
    return rv_ok == NUM_GRAINS ? 0 : 1;
}
