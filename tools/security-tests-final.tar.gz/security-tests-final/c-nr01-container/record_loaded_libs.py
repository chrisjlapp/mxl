#!/usr/bin/env python3
"""Record the libmxl paths actually mapped by writer and reader processes (evidence)."""
import re, subprocess, sys, time, uuid, os, shutil
sys.path.insert(0, "/home/chlapp/projects/mxl-security-container-tests")
from test_nonroot_container import flow_fixture
HERE = "/home/chlapp/projects/mxl-security-container-tests"
PROBE = f"{HERE}/probe_capture"
dom = f"/dev/shm/cnr01/libprobe-{os.getpid()}"
os.makedirs(dom, exist_ok=True)
fd = flow_fixture("/tmp", uuid.uuid4())

def maps_of(pid):
    try:
        with open(f"/proc/{pid}/maps") as f:
            return sorted({l.split()[-1] for l in f if "libmxl" in l or "libfabric" in l})
    except Exception:
        return []

w = subprocess.Popen([PROBE, "writer", dom, fd], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
w.stdin.write(f"WRITE 42 0 0\nHOLD 8\n"); w.stdin.flush()
time.sleep(1.5)
wm = maps_of(w.pid)
print("WRITER pid", w.pid, "mapped:", wm)
uid = re.search(r"uuid=([0-9a-f-]+)", "".join([]) or "")  # get uuid from stdout lines below
out_lines = []
import threading
lines = []
def pump():
    for l in w.stdout: lines.append(l)
threading.Thread(target=pump, daemon=True).start()
time.sleep(0.5)
m = re.search(r"uuid=([0-9a-f-]+)", "\n".join(lines))
flow_uuid = m.group(1) if m else str(uuid.UUID(int=0))
r = subprocess.Popen([PROBE, "reader", dom, flow_uuid], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
time.sleep(0.7)
rm = maps_of(r.pid)
print("READER pid", r.pid, "mapped:", rm)
r.stdin.write("QUIT\n"); r.stdin.flush(); r.wait(timeout=15)
w.stdin.write("QUIT\n"); w.stdin.flush(); w.wait(timeout=15)
with open("/tmp/loaded-libs.txt", "w") as f:
    f.write(f"writer_pid={w.pid}\n" + "\n".join(wm) + f"\nreader_pid={r.pid}\n" + "\n".join(rm) + "\n")
shutil.rmtree(dom, ignore_errors=True)
os.unlink(fd)
