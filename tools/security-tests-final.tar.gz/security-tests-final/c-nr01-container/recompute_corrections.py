#!/usr/bin/env python3
"""Corrections pass for C-NR-01:
 1. Recompute full-payload comparisons FROM SAVED CAPTURES with the fixed
    compare_bytes (both hypotheses over the ENTIRE payload).
 2. Recompute verdicts with fixed make_verdict (grounded in post-attempt read,
    NOT-TESTED handling, None for n/a dimensions).
 3. Reclassify deployment rows as NOT TESTED (report-level; raw data preserved).
 No captures are rewritten; only derived fields are recomputed."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_nonroot_container import compare_bytes, make_verdict

RUNS = sorted(Path("runs").glob("cnr01-*/results.json"))
for f in RUNS:
    d = json.load(open(f))
    case = d["case"]
    for o in d["results"]:
        gr = o.get("grain", {})
        idx, size = gr.get("index"), gr.get("size")
        cr = Path(o["dir"])
        ar = o.get("actor_report", {})
        # which phase captures exist, and against which hypothesis to compare
        phases = [("baseline", "captures/baseline.bin", 0, "baseline_compare"),
                  ("read_after_attempt", "captures/post_attempt.bin",
                   32 if (ar.get("result") == "MUTATED") else 0, "post_attempt_compare"),
                  ("restored", "captures/restored.bin", 0, "restored_compare")]
        for label, cap, win, key in phases:
            p = cr / cap
            if p.is_file():
                o[key] = compare_bytes(p, idx, size, win)
        # recompute verdict with corrected logic
        o["verdict"] = make_verdict(o)
        # deployment reclassification now lives in the orchestrator (vC) itself
        if case == "deployment" and False:
            o["verdict"]["not_tested"] = True
            o["verdict"]["experiment_completed"] = True
            o["verdict"]["sdk_returned_modified_bytes"] = None
            o["verdict"]["restoration_succeeded"] = None
            o["reclassification"] = ("Reclassified from 'LIMITATION' to NOT TESTED per review: the inspected "
                                     "container (qwen38-flash, vLLM inference) is not established as an MXL "
                                     "deployment and no mutation was attempted against it.")
    json.dump(d, open(f, "w"), indent=2)
    print(f"{f}: recomputed {len(d['results'])} reps")

# merged results.json
merged = {}
for f in RUNS:
    d = json.load(open(f)); merged[d["case"]] = d
json.dump(merged, open("results.json", "w"), indent=2)
print("merged results.json rebuilt")
