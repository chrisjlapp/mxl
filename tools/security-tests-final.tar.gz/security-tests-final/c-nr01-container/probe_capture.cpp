// C-NR-01 instrumented probe. Derived from
// /home/chlapp/Downloads/mxl-security-test-kit/probe.cpp (sha256
// 740ae13e3fe1dc15fa0ccac06b47c6b4a97a415c7b0fec7c277b1a0811b559c1) by Chris Lapp.
// The MXL SDK implementation is NOT modified. Additions over the original probe:
//   * HOLD <seconds>      - writer stays alive and idle (no SIGSTOP), proves liveness
//   * READFILE i exp path - exports the FULL SDK-returned payload for grain index i
//                           to `path`, validating returned length against known
//                           capacity BEFORE copying (harness safety rule).
// Payload generation and every SDK call are identical to the reference probe.
#include <mxl/flow.h>
#include <mxl/mxl.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <cstring>
#include <string>
#include <unistd.h>
#include <dlfcn.h>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <stdexcept>
#include <uuid/uuid.h>

static void result(std::string const& s) { std::cout << "RESULT " << s << std::endl; }
static unsigned char pattern(uint64_t index, size_t offset, unsigned seed) {
    return (unsigned char)((index * 17 + offset * 31 + seed) & 255);
}
static constexpr uint64_t MAX_PAYLOAD = 16ull * 1024 * 1024;

int main(int argc, char** argv) {
    std::cout.setf(std::ios::unitbuf);
    if (argc < 2) return 2;
    std::string mode = argv[1];
    if (mode == "version") {
        mxlVersionType v{}; auto s = mxlGetVersion(&v); Dl_info di{};
        dladdr(reinterpret_cast<void*>(&mxlCreateInstance), &di);
        result("status=" + std::to_string(s) + " version=" + (v.full ? v.full : "") +
               " library=" + (di.dli_fname ? di.dli_fname : ""));
        return s == 0 ? 0 : 3;
    }
    if (argc < 4) return 2;
    auto inst = mxlCreateInstance(argv[2], "{}");
    if (!inst) { result("instance=0"); return 3; }
    mxlFlowWriter w{}; mxlFlowReader r{}; mxlFlowConfigInfo config{};
    mxlStatus setup;
    if (mode == "writer") {
        std::ifstream f(argv[3]); std::stringstream b; b << f.rdbuf();
        if (!f) { result("fixture=missing"); mxlDestroyInstance(inst); return 2; }
        bool created = false;
        setup = mxlCreateFlowWriter(inst, b.str().c_str(), nullptr, &w, &config, &created);
        result("create=" + std::to_string(setup) + " created=" + std::to_string(created) +
               " pid=" + std::to_string(getpid()) + " uid=" + std::to_string(geteuid()) +
               " gid=" + std::to_string(getegid()) +
               " ring=" + std::to_string(setup == 0 ? config.discrete.grainCount : 0) +
               " uuid=" + [&]{ char buf[64]; uuid_unparse_lower(config.common.id, buf); return std::string(buf); }());
        if (setup != 0) { mxlDestroyInstance(inst); return 3; }
    } else if (mode == "reader") {
        setup = mxlCreateFlowReader(inst, argv[3], nullptr, &r);
        result("reader=" + std::to_string(setup) + " pid=" + std::to_string(getpid()) +
               " uid=" + std::to_string(geteuid()) + " gid=" + std::to_string(getegid()));
        if (setup != 0) { mxlDestroyInstance(inst); return 3; }
    } else { mxlDestroyInstance(inst); return 2; }

    std::string line;
    while (std::getline(std::cin, line)) {
        std::istringstream in(line); std::string cmd; in >> cmd;
        if (cmd == "QUIT") break;
        if (cmd == "WRITE" && w) {
            uint64_t index = 0; unsigned seed = 0, delay = 0; in >> index >> seed >> delay;
            mxlGrainInfo g{}; uint8_t* p = nullptr;
            auto s = mxlFlowWriterOpenGrain(w, index, &g, &p);
            auto size = g.grainSize;
            if (s != 0 || !p || size == 0 || size > MAX_PAYLOAD) {
                result("open=" + std::to_string(s) + " invalid_payload=1"); continue;
            }
            for (size_t k = 0; k < size; k++) { p[k] = pattern(index, k, seed); if (delay && k % 4096 == 0) usleep(delay); }
            g.validSlices = g.totalSlices;
            auto c = mxlFlowWriterCommitGrain(w, &g);
            result("open=" + std::to_string(s) + " commit=" + std::to_string(c) +
                   " index=" + std::to_string(index) + " size=" + std::to_string(size) +
                   " total=" + std::to_string(g.totalSlices));
        } else if (cmd == "HOLD") {
            // Writer remains alive, idle, unstopped (state S). Heartbeat lets the
            // orchestrator prove liveness across the whole sequence.
            unsigned seconds = 0; in >> seconds;
            for (unsigned i = 0; i < seconds; i++) { sleep(1); }
            result("hold=done pid=" + std::to_string(getpid()));
        } else if (cmd == "READFILE" && r) {
            uint64_t index = 0, expected = 0; in >> index >> expected;
            std::string outpath; in >> outpath;
            uint64_t timeout = 5000000000ULL;
            mxlGrainInfo g{}; uint8_t* p = nullptr;
            auto s = mxlFlowReaderGetGrain(r, index, timeout, &g, &p);
            // Validate returned length against known capacity before any copy.
            uint64_t copied = 0; int unsafe = 0;
            if (s == MXL_STATUS_OK) {
                if (p == nullptr || g.grainSize != expected || expected == 0 || expected > MAX_PAYLOAD) {
                    unsafe = 1;
                } else {
                    FILE* of = fopen(outpath.c_str(), "wb");
                    if (of) { copied = fwrite(p, 1, expected, of); fclose(of); }
                    else { unsafe = 2; }
                }
            }
            result("read=" + std::to_string(s) + " index=" + std::to_string(g.index) +
                   " size=" + std::to_string(g.grainSize) + " total=" + std::to_string(g.totalSlices) +
                   " valid=" + std::to_string(g.validSlices) + " copied=" + std::to_string(copied) +
                   " unsafe=" + std::to_string(unsafe) + " out=" + outpath);
        } else { result("command=invalid"); }
    }
    if (w) result("releaseWriter=" + std::to_string(mxlReleaseFlowWriter(inst, w)));
    if (r) result("releaseReader=" + std::to_string(mxlReleaseFlowReader(inst, r)));
    result("destroy=" + std::to_string(mxlDestroyInstance(inst)));
    return 0;
}
