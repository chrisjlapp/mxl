#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2025 Chris Lapp (test instrumentation only; MXL SDK implementation NOT modified)
"""
C-NR-01  Can a NON-ROOT container actor modify shared MXL grain payloads and have
         the changes be returned through the MXL SDK?
Host orchestration + verdict generation.

Adapted from test_integration_security.cpp (host suite, preserved untouched at
/home/chlapp/projects/mxl/lib/tests/):
  - Security A `runFileWriteInChild` (~line 232)   -> replaced by a fresh CONTAINER actor process
  - Security A different-user check (~line 1313, gated on geteuid()==0) -> generalized: no root gate
  - Security B "external grain payload modification" -> concept reused: backing grain file =
      <domain>/<uuid>.mxl-flow/grains/data.<index % grainCount>, payload at offset 8192 (VERIFIED, not assumed)
  - Security C3 competing writers                  -> pattern reused: fresh processes, no inherited state
  - Security F container environment               -> reused for environment notes ONLY (not proof of isolation)

Interface:
  python3 test_nonroot_container.py --case <baseline|deployment|owner-rw|group-rw|excluded-rw|group-ro> \
      --repeats <count> --output <new_run_directory>
"""
import argparse, hashlib, json, os, re, secrets, shutil, subprocess, sys, threading, time
import uuid as _uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
SDK_SRC = "/home/chlapp/projects/mxl"
BASELINE_LIB = "/home/chlapp/projects/mxl-security-baseline/build/lib/libmxl.so.1.2"
HOST_LIB = "/home/chlapp/projects/mxl/build/lib/libmxl.so.1.2"
LIB = BASELINE_LIB if Path(BASELINE_LIB).is_file() else HOST_LIB
PROBE = HERE / "probe_capture"
ACTOR = HERE / "container_actor.py"
FLOW_TEMPLATE = Path(SDK_SRC) / "lib/tests/data/v210_flow.json"
DOMAIN_ROOT = Path("/dev/shm/cnr01")
IMAGE = "qwen38-flash-dgx:v0.31"
IMAGE_ID = "ab43035e1536"
ACTOR_TIMEOUT = 60
READER_TIMEOUT = 60
XOR_COUNT = 32
WRITER_HOLD = 420
DEPLOY_CONTAINER = "qwen38-flash"

CASES = {   # actor identity / domain mount; None = no external actor at all
    "baseline":    None,
    "deployment":  {"user": None,       "mode": "rw", "fresh": False},  # real deployment's declared identity
    "owner-rw":    {"user": "1000:1000", "mode": "rw", "fresh": True},
    "group-rw":    {"user": "2000:1000", "mode": "rw", "fresh": True},
    "excluded-rw": {"user": "2001:2001", "mode": "rw", "fresh": True},
    "group-ro":    {"user": "2000:1000", "mode": "ro", "fresh": True},
}

# ------------------------------------------------------------------ helpers
def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    return h.hexdigest()

def pattern_byte(index, offset):   # identical to probe.cpp pattern(index, offset, seed=0)
    return (index * 17 + offset * 31) & 255

def run(cmd, timeout=60, input=None):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, input=input)
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        return 124, (e.stdout or ""), (e.stderr or "") + "\n<harness timeout>"

class Liveness:
    """Sample writer state externally every 0.5 s; proves it stayed alive + idle."""
    def __init__(self, pid):
        self.pid, self.samples, self.stop = pid, [], threading.Event()
        self.th = threading.Thread(target=self._run, daemon=True); self.th.start()
    def _run(self):
        while not self.stop.is_set():
            try:
                st = Path(f"/proc/{self.pid}/stat").read_text().split(") ", 1)[1].split()[0]
                self.samples.append({"t": round(time.time(), 3), "state": st})
            except FileNotFoundError:
                self.samples.append({"t": round(time.time(), 3), "state": "GONE"}); break
            time.sleep(0.5)
    def summary(self):
        self.stop.set(); self.th.join(timeout=2)
        states = {}
        for s in self.samples: states[s["state"]] = states.get(s["state"], 0) + 1
        return {"samples": len(self.samples), "states": states,
                "ever_gone": any(s["state"] == "GONE" for s in self.samples)}

def flow_fixture(flowdir, uid):
    base = json.loads(FLOW_TEMPLATE.read_text())
    base["id"] = str(uid)
    base["label"] = "C-NR-01"
    for t in list(base.get("tags", {})):
        if "grouphint" in t:
            base["tags"][t] = [f"cnr01-{secrets.token_hex(2)}:Video"]
    p = Path(flowdir) / "flow.json"
    p.write_text(json.dumps(base))
    return str(p)

def spawn_writer(domain, fdpath, script):
    def preexec(): os.umask(0o002)     # fixture perms established AT CREATION (0664/0775)
    proc = subprocess.Popen([str(PROBE), "writer", str(domain), fdpath],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, bufsize=1, preexec_fn=preexec)
    lines = []
    def pump():
        for l in proc.stdout: lines.append(l.rstrip())
    threading.Thread(target=pump, daemon=True).start()
    for l in script: proc.stdin.write(l + "\n")
    proc.stdin.flush()
    return proc, lines

def wait_for(lines, prefix, timeout):
    end = time.time() + timeout
    while time.time() < end:
        for l in lines:
            if prefix in l: return l
        time.sleep(0.02)
    return None

def sdk_read_one_shot(domain, uid, index, expected_size, out, tries=40, delay=0.25):
    """Fresh reader process, one exact index, full payload exported.
    Every attempt is recorded; passing REQUIRES status 0 AND complete copied length AND
    unsafe==0. Timeouts / missing output / unsafe capture can only fail a run, never pass it."""
    attempts, rc, out_s, err_s, status = [], 0, "", "", "no-attempt"
    for i in range(tries):
        rc, out_s, err_s = run([str(PROBE), "reader", str(domain), str(uid)],
                               input=f"READFILE {index} {expected_size} {out}\nQUIT\n",
                               timeout=READER_TIMEOUT)
        if rc == 124:
            attempts.append({"try": i, "status": "harness-timeout"})
            return {"status": "harness-timeout", "attempts": attempts,
                    "raw": (out_s + err_s)[:2000], "rc": rc}
        m = re.search(r"RESULT read=(-?\d+) index=(\d+) size=(\d+) total=(\d+) valid=(\d+) copied=(\d+) unsafe=(\d+)", out_s)
        status = m.group(1) if m else "no-result"
        attempts.append({"try": i, "status": status,
                         **({"copied": int(m.group(6)), "unsafe": int(m.group(7))} if m else {})})
        if m and status == "0" and int(m.group(6)) == expected_size and int(m.group(7)) == 0:
            return {"status": 0, "reported_index": int(m.group(2)), "grain_size": int(m.group(3)),
                    "totalSlices": int(m.group(4)), "validSlices": int(m.group(5)),
                    "copied": int(m.group(6)), "unsafe": 0, "attempts": attempts,
                    "raw": out_s.strip(), "rc": rc}
        time.sleep(delay)
    return {"status": status, "attempts": attempts, "raw": (out_s + err_s)[:2000], "rc": rc}

def compare_bytes(path, index, size, mutated_first=0):
    """Full-payload comparison against BOTH hypotheses over the ENTIRE payload:
    'original' = pattern; 'modified' = pattern XOR 0xFF for offsets < mutated_first,
    pattern elsewhere. A capture only satisfies a hypothesis if every byte matches."""
    p = Path(path)
    if not p.is_file() or p.stat().st_size != size:
        return {"valid": False, "reason": "missing or short capture", "mismatches": None}
    data = p.read_bytes()
    mm_off, mm_orig, mm_mod = [], 0, 0
    for k in range(0, size, 65536):
        blk = data[k:k + 65536]
        for j, b in enumerate(blk):
            o = k + j
            exp = pattern_byte(index, o)
            exp_mod = (exp ^ 0xFF) if o < mutated_first else exp
            if b != exp:
                mm_orig += 1
                if len(mm_off) < 64: mm_off.append(o)
            if b != exp_mod:
                mm_mod += 1
    return {"valid": True, "mutated_window": mutated_first, "compared_bytes": size,
            "mismatch_vs_original": mm_orig, "mismatch_vs_modified": mm_mod,
            "first_mismatch_offsets": mm_off[:32]}

def stat_chain(path):
    out, q = [], Path(path)
    while True:
        try:
            s = os.stat(q)
            out.append({"path": str(q), "mode": oct(s.st_mode & 0o7777), "uid": s.st_uid, "gid": s.st_gid})
        except Exception as e:
            out.append({"path": str(q), "error": str(e)})
        if str(q) == "/" or q.parent == q: break
        q = q.parent
    # POSIX ACLs on the target and its ancestors (empty output = no ACL beyond mode bits)
    rc, out_s, _ = run(["getfacl", "-p", str(path)], timeout=10)
    return {"stat": out, "getfacl_target_and_ancestors": out_s.strip() if rc == 0 else f"<getfacl rc={rc}>"}

def mount_evidence(path):
    """Effective mount for a host path (fstype + flags) via findmnt."""
    rc, out_s, _ = run(["findmnt", "-T", str(path), "-n", "-o", "TARGET,SOURCE,FSTYPE,OPTIONS"], timeout=10)
    return out_s.strip() if rc == 0 and out_s.strip() else f"<findmnt rc={rc}>"

# ------------------------------------------------------------------ one repetition
def run_case(case, rep, rundir, log):
    cr = rundir / case / f"rep{rep}"
    for sub in ("captures", "reports", "logs"): (cr / sub).mkdir(parents=True, exist_ok=True)
    os.chmod(cr / "reports", 0o777)   # host admin setup: world-writable ONLY for the actor report dir
    obs = {"case": case, "rep": rep, "dir": str(cr), "timeline": [], "invalid_reasons": []}
    # security-profile configuration captured per repetition (runtime, not inferred)
    src, sinfo, _ = run(["docker", "info", "--format", "{{json .SecurityOptions}}"], timeout=15)
    obs["docker_security_options"] = sinfo.strip() or f"<rc={src}>"
    def mark(s):
        obs["timeline"].append({"t": round(time.time(), 3), "ev": s}); log.append(f"[{case}/r{rep}] {s}")

    dom = DOMAIN_ROOT / f"{case}-{rep}-{secrets.token_hex(3)}"
    dom.mkdir(parents=True, exist_ok=True)
    uid = _uuid.uuid4(); obs["flow_uuid"] = str(uid)
    fd = flow_fixture(cr, uid)
    grain_index = 1000000 + secrets.randbelow(900000000)

    proc, lines, live = None, [], None
    try:
        proc, lines = spawn_writer(dom, fd, [f"WRITE {grain_index} 0 0", f"HOLD {WRITER_HOLD}"])
        ok = wait_for(lines, "create=", 20)
        m = re.search(r"create=(\d+) created=(\d) pid=(\d+) uid=(\d+) gid=(\d+) ring=(\d+) uuid=([0-9a-f-]+)", ok or "")
        if not m or m.group(1) != "0" or m.group(2) != "1":
            obs["invalid_reasons"].append(f"writer setup failed: {ok}"); return obs
        obs["writer"] = {"pid": proc.pid, "euid": int(m.group(4)), "egid": int(m.group(5)), "setup": ok}
        live = Liveness(proc.pid)
        wr = wait_for(lines, f"index={grain_index}", 20)
        m2 = re.search(r"open=0 commit=0 index=(\d+) size=(\d+) total=(\d+)", wr or "")
        if not m2:
            obs["invalid_reasons"].append(f"commit record missing: {wr}"); return obs
        size, total = int(m2.group(2)), int(m2.group(3))
        obs["grain"] = {"index": int(m2.group(1)), "size": size, "totalSlices": total, "seed": 0}
        mark(f"published index={m2.group(1)} size={size} slices={total}")

        ring = int(m.group(6))
        slot = grain_index % ring
        grain_file = dom / f"{uid}.mxl-flow" / "grains" / f"data.{slot}"
        if not grain_file.is_file():
            gdir = dom / f"{uid}.mxl-flow" / "grains"
            found = sorted(str(p.name) for p in gdir.iterdir()) if gdir.is_dir() else []
            obs["invalid_reasons"].append(f"ring-mapped grain file data.{slot} absent; dir has {found}")
            return obs
        gstat = os.stat(grain_file)
        obs["backing_file"] = {"path": str(grain_file), "ring": ring, "slot": slot,
                               "mode": oct(gstat.st_mode & 0o7777), "uid": gstat.st_uid, "gid": gstat.st_gid,
                               "dev": f"{os.major(gstat.st_dev)}:{os.minor(gstat.st_dev)}",
                               "ino": gstat.st_ino, "size": gstat.st_size,
                               "chain": stat_chain(grain_file), "mount": mount_evidence(grain_file)}
        # payload offset VERIFIED against on-disk bytes (MXL_GRAIN_PAYLOAD_OFFSET=8192 in this build)
        with open(grain_file, "rb") as f:
            window = f.read(min(gstat.st_size, size + 16384))
        off = window.find(bytes(pattern_byte(grain_index, j) for j in range(64)))
        obs["offset_verification"] = {"header_per_flow_hpp": 8192, "found": off,
                                      "file_size": gstat.st_size, "payload_size": size, "match": off == 8192}
        if off != 8192:
            obs["invalid_reasons"].append("payload offset verification failed — layout assumption invalid for this fixture")
            return obs
        mark("backing file + payload offset resolved via SDK ring mapping (not readdir order)")

        cap0 = cr / "captures" / "baseline.bin"
        rd = sdk_read_one_shot(dom, uid, grain_index, size, cap0)
        obs["read_baseline"] = rd
        cmp0 = compare_bytes(cap0, grain_index, size, 0)
        obs["baseline_compare"] = cmp0
        if rd["status"] != 0 or not cmp0["valid"] or cmp0["mismatch_vs_original"] != 0:
            obs["invalid_reasons"].append("baseline SDK readback did not match completely — experiment invalid")
            return obs
        mark("baseline full-payload SDK readback verified (0 mismatches)")

        if case == "baseline":
            capB = cr / "captures" / "post.bin"
            rd2 = sdk_read_one_shot(dom, uid, grain_index, size, capB)
            obs["read_post"] = rd2
            obs["post_compare"] = compare_bytes(capB, grain_index, size, 0)
            obs["post_attempt_compare"] = obs["post_compare"]   # baseline: no actor; payload must be unchanged
            mark("baseline case complete (no external actor)")
            return obs

        conf = CASES[case]
        if case == "deployment":
            # NOT TESTED (reclassified): this branch only INSPECTED the running
            # qwen38-flash container (a vLLM inference deployment, not an established
            # MXL deployment) and attempted a write to a path it does not mount.
            # No mutation was attempted through a real MXL domain and no isolation
            # claim can rest on it. Recorded observations below are environment notes.
            cmd = ["docker", "exec", DEPLOY_CONTAINER, "python3", "-c",
                   "import os;"
                   "print('pid',os.getpid());print('euid',os.geteuid());print('egid',os.getegid());"
                   "print('groups',os.getgroups());"
                   "st=open('/proc/self/status').read();"
                   "print('cap_eff',[l for l in st.splitlines() if l.startswith('CapEff')][0]);"
                   "print('nnp',[l for l in st.splitlines() if l.startswith('NoNewPrivs')][0]);"
                   "print('uidmap',open('/proc/self/uid_map').read().strip());"
                   "print(open('/proc/self/mountinfo').read())"]
            rc, out_s, err_s = run(cmd, timeout=ACTOR_TIMEOUT)
            obs["actor_command"] = cmd
            obs["actor_exit"], obs["actor_stdout"], obs["actor_stderr"] = rc, out_s.strip()[:6000], err_s.strip()[:2000]
            mrc, mout, _ = run(["docker", "inspect", DEPLOY_CONTAINER, "--format", "{{json .Mounts}}"])
            obs["deployment_mounts_inspected"] = mout.strip() if mrc == 0 else f"<inspect rc={mrc}>"
            test_domain_mounted = str(dom) in mout
            obs["deployment_test_domain_mounted"] = test_domain_mounted
            obs["actor_report"] = {"result": "NOT-TESTED",
                                   "note": "mutation not attempted: inspected container is not established "
                                           "as an MXL deployment; mount inspection recorded instead"}
            mark("deployment case: NOT TESTED (identity provenance unestablished; mount inspection recorded)")
            capA = cr / "captures" / "post_attempt.bin"
            rdA = sdk_read_one_shot(dom, uid, grain_index, size, capA)
            obs["read_after_attempt"] = rdA
            obs["post_attempt_compare"] = compare_bytes(capA, grain_index, size, 0)
            obs["restore"] = {"needed": False, "performed": False}
            obs["not_tested_reason"] = ("No verified MXL deployment container exists on this host to act as the "
                                        "actor; the running qwen38-flash container's relevance to MXL is unproven. "
                                        "Deployment applicability remains open pending a real deployment.")
            return obs

        user_arg, mount_mode = conf["user"], conf["mode"]
        u, g = (int(x) for x in user_arg.split(":"))
        auth = "file-owner" if u == gstat.st_uid else ("group" if g == gstat.st_gid else "none")
        obs["actor_identity_requested"] = {"uid": u, "gid": g, "authorized_by": auth,
                                          "file": {"uid": gstat.st_uid, "gid": gstat.st_gid,
                                                   "mode": oct(gstat.st_mode & 0o7777)}}
        rep_json = {"result": "MISSING-REPORT"}
        capfile = cr / "reports" / "actor_report.json"
        if capfile.exists(): capfile.unlink()
        head_exp = hashlib.sha256(bytes(pattern_byte(grain_index, j) for j in range(XOR_COUNT))).hexdigest()
        cmd = ["docker", "run", "--rm", "-i", "--network", "none",
               "--entrypoint", "python3",
               "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
               "--label", f"cnr01={case}-r{rep}",
               "-v", f"{dom}:/domain:{mount_mode}",
               "-v", f"{cr / 'reports'}:/reports:rw",
               "-v", f"{ACTOR}:/actor/container_actor.py:ro",
               "--user", user_arg,
               IMAGE, "/actor/container_actor.py",
               "--path", f"/domain/{uid}.mxl-flow/grains/data.{slot}",
               "--offset", "8192", "--count", str(XOR_COUNT), "--mode", "xor",
               "--expect-sha256", head_exp, "--out", "/reports/actor_report.json"]
        obs["actor_command"] = cmd
        obs["domain_mount"] = f"{dom}:/domain:{mount_mode}"
        rc, out_s, err_s = run(cmd, timeout=ACTOR_TIMEOUT)
        obs["actor_exit"], obs["actor_stdout"], obs["actor_stderr"] = rc, out_s.strip()[:4000], err_s.strip()[:4000]
        if rc == 124:
            obs["invalid_reasons"].append("actor timed out — invalid repetition, not a security result")
        if capfile.is_file():
            try: rep_json = json.loads(capfile.read_text())
            except Exception as e: obs["invalid_reasons"].append(f"actor report unreadable: {e}")
        elif rc != 124:
            obs["invalid_reasons"].append(f"actor produced no report (rc={rc}) — startup failure, not an access denial")
        obs["actor_report"] = rep_json
        creds = rep_json.get("creds", {})
        conds = {"euid_nonzero": creds.get("euid", 0) != 0,
                 "cap_eff_zero": creds.get("cap_eff_hex", "x").strip("0") == "",
                 "no_new_privs": creds.get("no_new_privs") == "1"}
        obs["nonroot_conditions"] = conds
        if rep_json.get("result") in ("MUTATED", "DENIED", "WRITE_INCOMPLETE") and not all(conds.values()):
            obs["invalid_reasons"].append(f"actor non-root conditions violated: {conds}")
        mark(f"actor done rc={rc} result={rep_json.get('result')}")

        capA = cr / "captures" / "post_attempt.bin"
        rdA = sdk_read_one_shot(dom, uid, grain_index, size, capA)
        obs["read_after_attempt"] = rdA
        succeeded = rep_json.get("result") == "MUTATED" and rep_json.get("write", {}).get("written") == XOR_COUNT
        obs["post_attempt_compare"] = compare_bytes(capA, grain_index, size, XOR_COUNT if succeeded else 0)
        mark("post-attempt SDK readback captured")

        if succeeded:   # restore by host fixture owner only (actor fds already closed)
            with open(grain_file, "r+b") as f:
                f.seek(8192); b = f.read(XOR_COUNT)
                f.seek(8192); f.write(bytes(x ^ 0xFF for x in b)); f.flush()
            obs["restore"] = {"needed": True, "performed": True,
                              "by": "host fixture owner", "owner_uid": os.stat(grain_file).st_uid,
                              "unchanged_metadata": oct(os.stat(grain_file).st_mode & 0o7777)}
            capR = cr / "captures" / "restored.bin"
            rdR = sdk_read_one_shot(dom, uid, grain_index, size, capR)
            obs["read_restored"] = rdR
            obs["restored_compare"] = compare_bytes(capR, grain_index, size, 0)
            mark("restore + verification read complete")
        else:
            obs["restore"] = {"needed": False, "performed": False}
        return obs
    finally:
        if live: obs["writer_liveness"] = live.summary()
        if proc and proc.poll() is None:
            try:
                proc.stdin.write("QUIT\n"); proc.stdin.flush()
            except Exception: pass
            try: proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try: proc.wait(timeout=10)
                except Exception: proc.kill()
        obs["writer_final"] = {"exit": proc.returncode if proc else None,
                               "alive_throughout": bool(live and not live.summary()["ever_gone"])} if proc else {}
        shutil.rmtree(dom, ignore_errors=True)

# ------------------------------------------------------------------ verdict (dimensions kept separate)
def make_verdict(obs):
    """Six dimensions, reported separately. Each dimension is grounded in the
    experiment's OWN sequence (baseline gate, actor attempt, post-attempt readback),
    not just the baseline read."""
    ar = obs.get("actor_report", {})
    rd = obs.get("read_baseline", {})
    rA = obs.get("read_after_attempt", {})
    pc = obs.get("post_attempt_compare", {})
    rc = obs.get("restored_compare", {})
    size = obs.get("grain", {}).get("size")
    baseline_ok = (rd.get("status") == 0 and rd.get("copied") == size
                   and obs.get("baseline_compare", {}).get("valid")
                   and obs["baseline_compare"].get("mismatch_vs_original") == 0)
    hard_invalid = [x for x in obs.get("invalid_reasons", []) if not x.startswith("LIMITATION")]
    not_tested = ar.get("result") == "NOT-TESTED"
    exp_completed = baseline_ok and not hard_invalid and not not_tested
    # post-attempt SDK read valid = the read the verdict depends on, not the baseline
    read_valid_post = (rA.get("status") == 0 and rA.get("copied") == size and rA.get("unsafe", 1) == 0)
    return {
        "experiment_completed": exp_completed,
        "not_tested": not_tested,
        "not_tested_reason": obs.get("not_tested_reason"),
        "actor_obtained_write_access": ar.get("result") == "MUTATED",
        "backing_bytes_changed": bool(ar.get("write", {}).get("confirmed_changed", False)),
        "sdk_read_valid_post_attempt": bool(read_valid_post),
        "sdk_returned_modified_bytes": None if (obs["case"] == "baseline" or not_tested) else bool(
            pc.get("valid") and pc.get("mismatch_vs_original") == XOR_COUNT
            and pc.get("mismatch_vs_modified") == 0 and read_valid_post),
        "sdk_integrity_error_reported": False if not_tested else (
            isinstance(rA.get("status"), int) and rA["status"] != 0),
        "restoration_succeeded": (bool(rc.get("valid") and rc.get("mismatch_vs_original") == 0)
                                  if obs.get("restore", {}).get("needed") else None),
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", required=True, choices=list(CASES))
    ap.add_argument("--repeats", type=int, default=1)
    ap.add_argument("--output", required=True)
    a = ap.parse_args()
    rundir = Path(a.output).resolve()   # absolute: docker bind sources must not be relative
    if rundir.exists(): sys.exit(f"refusing to reuse output directory: {rundir}")
    rundir.mkdir(parents=True)
    log = []
    vrc, vout, verr = run([str(PROBE), "version"])
    prov = {
        "sdk_commit": run(["git", "-C", SDK_SRC, "rev-parse", "HEAD"])[1].strip(),
        "sdk_note": "compatibility patches present in checkout (see evidence/sdk-compat-diff.txt); "
                    "libmxl core only — libmxl-fabrics/libfabric NOT loaded by this harness",
        "library_used": LIB, "library_sha256": sha256(LIB),
        "probe_capture_sha256": sha256(PROBE), "container_actor_sha256": sha256(ACTOR),
        "orchestrator_sha256": sha256(Path(__file__).resolve()),
        "reference_suite_sha256": sha256(Path(SDK_SRC) / "lib/tests/test_integration_security.cpp"),
        "image": IMAGE,
        "image_id": run(["docker", "inspect", IMAGE, "--format", "{{.Id}}"])[1].strip(),
        "image_short_id": run(["docker", "images", "--no-trunc", "--format",
                               "{{.ID}}", IMAGE])[1].strip(),
        "image_repo_digests": run(["docker", "inspect", IMAGE, "--format", "{{json .RepoDigests}}"])[1].strip(),
        "image_source_note": "local build (no registry RepoDigest) — .Id is the authoritative content hash",
        "docker_version": run(["docker", "--version"])[1].strip(),
        "compiler": run(["g++", "--version"])[1].splitlines()[0],
        "page_size": run(["getconf", "PAGE_SIZE"])[1].strip(),
        "shm_fstype": run(["stat", "-f", "-c", "%T", "/dev/shm"])[1].strip(),
        "probe_version": {"rc": vrc, "line": vout.strip(), "stderr": verr.strip()[:500]},
    }
    (rundir / "provenance.json").write_text(json.dumps(prov, indent=2))

    results = []
    for r in range(1, a.repeats + 1):
        obs = run_case(a.case, r, rundir, log)
        obs["verdict"] = make_verdict(obs)
        results.append(obs)
        (rundir / "results-partial.json").write_text(json.dumps(results, indent=2))
        (rundir / "run.log").write_text("\n".join(log) + "\n")
    (rundir / "results.json").write_text(json.dumps(
        {"provenance": prov, "case": a.case, "repeats": a.repeats, "results": results}, indent=2))
    (rundir / "run.log").write_text("\n".join(log) + "\n")
    print(json.dumps({"case": a.case,
                      "runs": [{"rep": o["rep"], "completed": o["verdict"]["experiment_completed"],
                                "write_access": o["verdict"]["actor_obtained_write_access"],
                                "sdk_modified_returned": o["verdict"]["sdk_returned_modified_bytes"],
                                "invalid": o["invalid_reasons"]} for o in results]}, indent=2))

if __name__ == "__main__":
    main()
