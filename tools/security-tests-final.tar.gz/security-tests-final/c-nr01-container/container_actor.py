#!/usr/bin/env python3
"""C-NR-01 container-side actor. Runs as the (non-root) actor identity INSIDE the
container. Records real credentials/capabilities/namespaces, then opens the SDK
grain backing file ITSELF and XORs the first N payload bytes with 0xFF at the
verified payload offset. No SDK involvement, no inherited writable fds.

Exit codes: 0 = mutation written in full; 4 = access denied (recorded);
            2 = usage/argument error; 3 = unexpected environment error.
Never treats a failure as success; every syscall return is reported.
"""
import argparse, ctypes, ctypes.util, json, os, socket, struct, sys, time

libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)
ERRNO_DENIED = (1, 13, 30)  # EPERM, EACCES, EROFS

def errno_name(e):
    try: return os.strerror(e)
    except Exception: return "?"

def read_proc(path):
    try:
        with open(path) as f: return f.read().strip()
    except Exception as exc:
        return f"<unreadable: {exc}>"

def credentials():
    libc.getuid.restype = ctypes.c_uint; libc.geteuid.restype = ctypes.c_uint
    libc.getgid.restype = ctypes.c_uint; libc.getegid.restype = ctypes.c_uint
    libc.getgroups.restype = ctypes.c_int
    ngroups = int(libc.getgroups(0, None))
    arr = (ctypes.c_uint * max(ngroups, 1))()
    libc.getgroups(len(arr), arr)
    caps_raw = read_proc("/proc/self/status").split("CapEff:")[1].split("\n")[0].strip() if "CapEff:" in read_proc("/proc/self/status") else ""
    status = read_proc("/proc/self/status")
    nonpriv = ""
    for line in status.splitlines():
        if line.startswith("NoNewPrivs:"): nonpriv = line.split(":")[1].strip()
    return {
        "pid": os.getpid(), "ppid": os.getppid(),
        "uid": libc.getuid(), "euid": libc.geteuid(),
        "gid": libc.getgid(), "egid": libc.getegid(),
        "groups": list(arr[:max(ngroups, 0)]),
        "cap_eff_hex": caps_raw,
        "cap_prm_hex": status.split("CapPrm:")[1].split("\n")[0].strip() if "CapPrm:" in status else "",
        "cap_bnd_hex": status.split("CapBnd:")[1].split("\n")[0].strip() if "CapBnd:" in status else "",
        "no_new_privs": nonpriv,
        "uid_map": read_proc("/proc/self/uid_map"),
        "gid_map": read_proc("/proc/self/gid_map"),
        "namespaces": {k: os.readlink(f"/proc/self/ns/{k}") for k in
                       ("mnt", "pid", "net", "user", "ipc", "uts", "cgroup")},
        "mountinfo": read_proc("/proc/self/mountinfo"),
        "hostname": socket.gethostname(),
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--path", required=True, help="absolute grain file path as seen inside the container")
    ap.add_argument("--offset", required=True, type=int, help="verified payload offset in the grain file")
    ap.add_argument("--count", type=int, default=32, help="bytes to XOR (bounded)")
    ap.add_argument("--mode", choices=["xor", "restore"], default="xor")
    ap.add_argument("--expect-sha256", default="", help="optional: verify first count bytes match this hash-of-original before writing")
    ap.add_argument("--out", required=True, help="JSON report path (must be writable by actor)")
    a = ap.parse_args()
    if a.count < 1 or a.count > 4096: return 2

    rep = {"t0": time.time(), "args": {k: str(v) for k, v in vars(a).items()},
           "creds": credentials(), "fd_inventory_before_open": {}, "result": "init"}
    try:
        rep["fd_inventory_before_open"] = sorted(os.listdir("/proc/self/fd"))
    except Exception as e:
        rep["fd_inventory_before_open"] = f"<{e}>"

    import hashlib, subprocess
    try:
        st = os.stat(a.path)
        rep["target_stat"] = {"dev": os.major(st.st_dev), "minor": os.minor(st.st_dev),
                              "ino": st.st_ino, "mode": oct(st.st_mode), "uid": st.st_uid,
                              "gid": st.st_gid, "size": st.st_size, "nlink": st.st_nlink}
    except Exception as e:
        rep["target_stat"] = f"<stat failed: {e}>"

    data_before = None
    fd = -1
    try:
        # open(O_RDWR) is the access-under-test. pwrite is bounded to --count bytes.
        fd = os.open(a.path, os.O_RDWR)
        rep["open"] = {"ok": True, "fd": fd}
        if a.mode == "xor":
            current_op = "pread"
            buf = os.pread(fd, a.count, a.offset)
            rep["read_before"] = {"requested": a.count, "returned": len(buf),
                                  "sha256": hashlib.sha256(buf).hexdigest()}
            if a.expect_sha256 and hashlib.sha256(buf).hexdigest() != a.expect_sha256:
                rep["result"] = "PRECONDITION_MISMATCH"   # refuse to write the wrong bytes
            else:
                current_op = "pwrite"
                w = os.pwrite(fd, bytes(b ^ 0xFF for b in buf), a.offset)
                current_op = "pread-confirm"
                buf2 = os.pread(fd, a.count, a.offset)
                rep["write"] = {"op": "xor-0xFF", "requested": len(buf), "written": w,
                                "sha256_after": hashlib.sha256(buf2).hexdigest(),
                                "confirmed_changed": buf2 != buf}
                rep["result"] = "MUTATED" if (w == a.count and buf2 != buf) else "WRITE_INCOMPLETE"
        else:  # restore: XOR again with FF returns original bytes
            buf = os.pread(fd, a.count, a.offset)
            w = os.pwrite(fd, bytes(b ^ 0xFF for b in buf), a.offset)
            buf2 = os.pread(fd, a.count, a.offset)
            rep["write"] = {"op": "restore-xor-0xFF", "requested": len(buf), "written": w,
                            "sha256_after": hashlib.sha256(buf2).hexdigest()}
            rep["result"] = "RESTORED" if w == a.count else "WRITE_INCOMPLETE"
    except OSError as e:
        rep.setdefault("open", {"ok": False, "op": locals().get("current_op", "open")})
        rep["open"].update({"errno": e.errno, "strerror": errno_name(e.errno or 0)})
        rep["result"] = "DENIED" if (e.errno or 0) in ERRNO_DENIED else "ERROR"
        # If denial happened AFTER a successful open (pread/pwrite), record it under write attempt too
        if rep["open"]["ok"] is False and getattr(e, "filename", None) == a.path and e.errno in (2,):
            rep["open"].update({"errno": e.errno, "strerror": errno_name(e.errno)})
        rep["error"] = repr(e)
    except BaseException as e:
        rep["result"] = "ERROR"; rep["error"] = repr(e)
    finally:
        if fd >= 0:
            try: os.close(fd); rep["closed"] = True
            except OSError as e: rep["closed"] = {"errno": e.errno}
    rep["t1"] = time.time()

    code = {"MUTATED": 0, "RESTORED": 0, "DENIED": 4, "PRECONDITION_MISMATCH": 5}.get(rep["result"], 3)
    rep["exit_code"] = code
    try:
        with open(a.out, "w") as f: json.dump(rep, f, indent=2)
    except Exception as e:
        print(json.dumps(rep)); print(f"report write failed: {e}", file=sys.stderr)
    return code

errno_EACCES = 13

if __name__ == "__main__":
    sys.exit(main())
