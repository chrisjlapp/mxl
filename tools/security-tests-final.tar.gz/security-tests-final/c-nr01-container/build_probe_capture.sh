#!/usr/bin/env bash
# Reproducible build for probe_capture (C-NR-01). SDK implementation untouched;
# links the existing baseline SDK build library, same flags as build_probe.py.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SDK="${MXL_SDK:-/home/chlapp/projects/mxl}"
LIB="${MXL_LIB:-/home/chlapp/projects/mxl-security-baseline/build/lib/libmxl.so.1.2}"
[ -f "$LIB" ] || LIB=/home/chlapp/projects/mxl/build/lib/libmxl.so.1.2
g++ -std=c++20 -O2 -Wall -Wextra \
    -I"${SDK}/lib/include" \
    "${HERE}/probe_capture.cpp" \
    "${LIB}" -Wl,-rpath,"$(dirname "${LIB}")" \
    -ldl -pthread -luuid \
    -o "${HERE}/probe_capture" 2> "${HERE}/build_probe_capture.log"
"${HERE}/probe_capture" version | tee -a "${HERE}/build_probe_capture.log"
sha256sum "${HERE}/probe_capture" "${LIB}" >> "${HERE}/build_probe_capture.log"
