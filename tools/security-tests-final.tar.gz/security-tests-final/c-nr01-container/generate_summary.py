#!/usr/bin/env python3
"""Generate SUMMARY.md + merged results.json + SHA256SUMS for C-NR-01 runs."""
import hashlib, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
runs = sorted(ROOT.glob("runs/cnr01-*"))
rows, merged = [], {}
for rd in runs:
    fj = rd / "results.json"
    if not fj.is_file(): continue
    data = json.loads(fj.read_text())
    merged[data["case"]] = data
    for o in data["results"]:
        v = o["verdict"]; ar = o.get("actor_report", {})
        pc = o.get("post_attempt_compare", {}) or {}
        cmp_ = pc.get("mismatch_vs_original", "-") if pc.get("valid") else "INVALID"
        rows.append({
            "case": data["case"], "rep": o["rep"],
            "uuid": o.get("flow_uuid", ""), "index": o.get("grain", {}).get("index", ""),
            "completed": v["experiment_completed"],
            "actor_result": ar.get("result", "-"),
            "write_access": v["actor_obtained_write_access"],
            "bytes_changed": v["backing_bytes_changed"],
            "sdk_modified_returned": v.get("sdk_returned_modified_bytes"),
            "not_tested": v.get("not_tested", False),
            "mismatch_orig": cmp_,
            "integrity_error": v["sdk_integrity_error_reported"],
            "restored": v["restoration_succeeded"],
            "nonroot_ok": o.get("nonroot_conditions", {}),
            "invalid": o.get("invalid_reasons", []),
        })

def yn(b): return "yes" if b else "no"
def s3(b): return "n/a" if b is None else yn(b)
L = []
L.append("# C-NR-01 — Non-root container actor vs shared MXL grain payloads\n")
L.append("**Experiment:** re-test the prerequisite for finding 5.1.1 of the MXL security paper: can a non-root")
L.append("container process modify shared grain payload bytes such that the MXL SDK reader returns the change?")
L.append("**Method:** real MXL SDK writer/reader processes (unmodified libmxl), one fresh flow+domain per repetition,")
L.append("external actor in a hardened Docker container (`--cap-drop ALL`, `no-new-privileges`, `--network none`,")
L.append("no privileged mode, no host PID, no devices, no engine socket), XOR of the first 32 payload bytes at the")
L.append("SDK-layout-verified offset (8192), full-payload SDK readback before and after.\n")
L.append("## Results matrix\n")
L.append("| case | rep | completed | actor open | write access | backing changed | SDK returned modified | mismatches vs original | integrity error | restored | nonroot conditions |")
L.append("|---|---|---|---|---|---|---|---|---|---|---|")
for r in rows:
    nr = r["nonroot_ok"]
    nrs = ("euid≠0:" + yn(nr.get("euid_nonzero")) + " caps=0:" + yn(nr.get("cap_eff_zero")) +
           " NNP:" + yn(nr.get("no_new_privs"))) if nr else "n/a"
    L.append(f"| {r['case']} | {r['rep']} | {s3(r['completed'])}{' **NOT TESTED**' if r.get('not_tested') else ''} "
             f"| {r['actor_result']} | {s3(r['write_access'])} "
             f"| {s3(r['bytes_changed'])} | {s3(r['sdk_modified_returned'])} | {r['mismatch_orig']} "
             f"| {s3(r['integrity_error'])} | {s3(r['restored'])} | {nrs} |")
L.append("")

# per-case rollup
L.append("## Per-case rollup\n")
from collections import defaultdict
by = defaultdict(list)
for r in rows: by[r["case"]].append(r)
for case, rs in by.items():
    ok = sum(1 for x in rs if x["completed"])
    wa = sum(1 for x in rs if x["write_access"])
    sm = sum(1 for x in rs if x["sdk_modified_returned"])
    L.append(f"- **{case}**: {ok}/{len(rs)} valid repetitions; write access {wa}/{ok}; "
             f"SDK returned modified bytes {sm}/{wa if wa else ok}.")
    for x in rs:
        for iv in x["invalid"]:
            L.append(f"  - rep {x['rep']}: {iv}")
L.append("")
(ROOT / "SUMMARY-rows.json").write_text(json.dumps(rows, indent=2))
print(f"{len(rows)} rows from {len(merged)} cases")
