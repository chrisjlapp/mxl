#!/usr/bin/env bash
# V15 independent-process control orchestration.
# Usage: v15_pair.sh <tag> <outdir> <base_idx> <n> <seed> <service> [sender_extra_args...]
# Launches FRESH receiver + sender processes (exec'd, no inherited SDK state),
# readiness barriers on files, bounded deadlines, full captures via verify role.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BIN="$HERE/v15-roles"
BASE_LIB=/home/chlapp/projects/mxl-security-baseline/build/lib
export LD_LIBRARY_PATH=/opt/libfabric121/lib:$BASE_LIB:$BASE_LIB/fabrics/ofi

TAG=$1; OUT=$2; BASE=$3; N=$4; SEED=$5; SVC=$6; shift 6
SDOM=/dev/shm/mxl-v15mp-$TAG-s
RDOM=/dev/shm/mxl-v15mp-$TAG-r
mkdir -p "$OUT"
rm -f "$OUT"/tinfo-*.ready "$OUT"/tinfo-*.json "$OUT"/verify-done
rm -rf "$SDOM" "$RDOM"; mkdir -p "$SDOM" "$RDOM"
cp /home/chlapp/projects/mxl-security-baseline/tools/mxl-fabrics-demo/demo-flow.json "$OUT/flowdef.json" 2>/dev/null || \
  cp /tmp/mxl-target-flow.json "$OUT/flowdef.json"

# --- receiver (fresh process) ---
"$BIN" receiver "$TAG" "$OUT" "$RDOM" "$OUT/flowdef.json" "$OUT/tinfo-$TAG.json" "$SVC" > "$OUT/receiver.log" 2>&1 &
RPID=$!
# barrier: wait for non-empty tinfo file, 30 s deadline
ok=0
for _ in $(seq 1 300); do
  [ -s "$OUT/tinfo-$TAG.json" ] && [ -e "$OUT/tinfo-$TAG.json.ready" ] && { ok=1; break; }
  kill -0 $RPID 2>/dev/null || break
  sleep 0.1
done
if [ $ok -ne 1 ]; then echo "BARRIER-FAIL receiver-not-ready rc=$?"; wait $RPID; exit 3; fi
echo "barrier: receiver ready (pid $RPID, service $SVC)"

# --- sender (fresh process) ---
"$BIN" sender "$TAG" "$OUT" "$SDOM" "$OUT/flowdef.json" "$OUT/tinfo-$TAG.json" 192.168.100.1 "$BASE" "$N" "$SEED" "$OUT/verify-done" "$@" > "$OUT/sender.log" 2>&1 &
SPID=$!
sleep 2
kill -0 $RPID 2>/dev/null && kill -0 $SPID 2>/dev/null || { echo "PROCESS-DIED early"; }

# --- receiver verification in ANOTHER fresh process (exact indices, full payload) ---
FLOWID=$(python3 -c "import json;print(json.load(open('$OUT/flowdef.json'))['id'])")
"$BIN" verify "$OUT" "$RDOM" "$FLOWID" "$BASE" "$N" "$SEED" > "$OUT/verify.log" 2>&1
VRC=$?
touch "$OUT/verify-done"   # release barrier: endpoints can now shut down

wait $SPID; SRC=$?
kill -TERM $RPID 2>/dev/null; wait $RPID; RRC=$?
echo "exits: verify=$VRC sender=$SRC receiver=$RRC"
grep -E "^V RESULT|^S RESULT|^R COMMIT" "$OUT"/*.log 2>/dev/null | head -10
exit $VRC
