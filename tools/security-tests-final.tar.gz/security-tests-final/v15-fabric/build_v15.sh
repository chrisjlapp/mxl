#!/usr/bin/env bash
# V15 reproducible build (harness only; SDK untouched beyond previously disclosed compat patches)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BASE=/home/chlapp/projects/mxl-security-baseline
BUILDCMD="gcc -std=c11 -O2 -Wall -Wextra -o $HERE/v15-control $HERE/v15-control.c \
  -I$BASE/lib/include -I$BASE/lib/fabrics/include -I$BASE/build/include \
  -L$BASE/build/lib -L$BASE/build/lib/fabrics/ofi -L/opt/libfabric121/lib \
  -lmxl -lmxl-fabrics -lfabric -lstdc++ -Wl,-rpath,$BASE/build/lib -Wl,-rpath,$BASE/build/lib/fabrics/ofi -Wl,-rpath,/opt/libfabric121/lib"
echo "$BUILDCMD" > "$HERE/build-command.sh"
eval "$BUILDCMD" 2> "$HERE/build.log" || { echo BUILD-FAILED; cat "$HERE/build.log"; exit 1; }
echo "BUILD OK"; sha256sum "$HERE/v15-control"
