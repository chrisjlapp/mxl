#!/usr/bin/env bash
# T17-A: "stale target-information behavior after lifecycle change" — initiator-side RemoveTarget.
# The SDK exposes no revocation mechanism; this is NOT a revocation-bypass test.
# Deterministic sequence:
#   1. receiver A up; sender A queues n session grains, holds endpoint alive
#   2. verify session-A delivery through the receiver SDK (must pass, endpoints live)
#   3. THEN touch probe-gate -> sender calls RemoveTarget, queues ONE probe grain (base+n)
#   4. attribute probe grain at receiver: delivery-after-removal observation
# Usage: t17a.sh <rep> [extra sender flags e.g. --no-remove]
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BASE=/home/chlapp/projects/mxl-security-baseline
export LD_LIBRARY_PATH=/opt/libfabric121/lib:$BASE/build/lib:$BASE/build/lib/fabrics/ofi
REP=$1; shift || true
EXTRA="$*"
RUN=$HERE/runs/t17a-$REP-$(date +%H%M%S)
rm -rf "$RUN"; mkdir -p "$RUN/sessA"
FLOWID=$(python3 -c "import json;print(json.load(open('/tmp/mxl-target-flow.json'))['id'])")
SVC=718$REP
BASEA=$((53710$((40+REP))0000))
PROBE_IDX=$((BASEA + 3))

rm -rf /dev/shm/mxl-v15mp-t17a$REP-r /dev/shm/mxl-v15mp-t17a$REP-s
mkdir -p /dev/shm/mxl-v15mp-t17a$REP-r /dev/shm/mxl-v15mp-t17a$REP-s
"$HERE/v15-roles" receiver t17a$REP "$RUN" /dev/shm/mxl-v15mp-t17a$REP-r /tmp/mxl-target-flow.json "$RUN/tinfoA.json" "$SVC" > "$RUN/receiverA.log" 2>&1 &
RPID=$!
for i in $(seq 1 200); do [ -e "$RUN/tinfoA.json.ready" ] && break; sleep 0.1; done
[ -e "$RUN/tinfoA.json.ready" ] || { echo "BARRIER-FAIL"; kill $RPID 2>/dev/null; exit 3; }
echo "receiver-A ready pid=$RPID service=$SVC extra='$EXTRA'"

"$HERE/v15-roles" sender t17a$REP "$RUN" /dev/shm/mxl-v15mp-t17a$REP-s /tmp/mxl-target-flow.json "$RUN/tinfoA.json" 192.168.100.1 "$BASEA" 3 21 "$RUN/holdA" --probe-file "$RUN/probe-gate" $EXTRA > "$RUN/senderA.log" 2>&1 &
SPID=$!
sleep 2
echo "== 1. session-A delivery verification (endpoints live) =="
"$HERE/v15-roles" verify "$RUN/sessA" /dev/shm/mxl-v15mp-t17a$REP-r "$FLOWID" "$BASEA" 3 21 > "$RUN/verifyA.log" 2>&1
ARC=$?
grep "^V RESULT" "$RUN/verifyA.log" | sed 's/^/A-VERIFY: /'
if [ $ARC -ne 0 ]; then echo "T17A-INVALID (session-A control failed; lifecycle step not executed)"
  touch "$RUN/holdA" "$RUN/probe-gate"; kill $SPID $RPID 2>/dev/null; exit 4; fi

echo "== 2. lifecycle gate: touch probe-gate =="
touch "$RUN/probe-gate"
sleep 3
grep -E "^S REMOVETARGET|^S PROBE-GATE|^S QUEUED.*AFTER-REMOVE|^S TRANSFER-ERR" "$RUN/senderA.log" | head -5

echo "== 3. probe attribution (idx $PROBE_IDX seed 21; rc0=delivered-after-op, rc1=NOT-delivered) =="
"$HERE/v15-roles" verify "$RUN" /dev/shm/mxl-v15mp-t17a$REP-r "$FLOWID" "$PROBE_IDX" 1 21 > "$RUN/verifyProbe.log" 2>&1
PRC=$?
grep -E "^V RESULT|^V IDX" "$RUN/verifyProbe.log" | sed 's/^/PROBE: /'

touch "$RUN/holdA"; wait $SPID 2>/dev/null
kill -TERM $RPID 2>/dev/null; wait $RPID 2>/dev/null
CC=$(grep -cE "^R COMMIT" "$RUN/receiverA.log")
echo "receiver-commits=$CC (3 = A only, probe blocked; 4 = probe delivered)"
echo "T17A-RESULT rep=$REP a_verified=yes probe_delivered=$([ $PRC -eq 0 ] && echo yes || echo no) commits=$CC extra='$EXTRA'"
