/**
 * MXL V15 multi-process role harness — verbs/RoCEv2.
 * Roles (separate exec'd processes; no inherited SDK handles/fds):
 *   receiver <tag> <outdir> <domain> <flowdef> <tinfo_out> <service> [stopfile] [--no-adjust]
 *   sender   <tag> <outdir> <domain> <flowdef> <tinfo_in>  <localnode> <base_idx> <n> <seed> [stopfile] [--no-transfer]
 *   verify   <outdir> <domain> <flowid> <base_idx> <n> <seed>
 * Topology: same host, physically looped NIC (192.168.100.1 <-> 192.168.100.2), verbs RC. NOT a two-host test.
 */
#define _GNU_SOURCE 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/stat.h>
#include <mxl/mxl.h>
#include <mxl/flow.h>
#include <mxl/fabrics.h>

static uint8_t payload_byte(uint64_t idx, uint32_t j, uint32_t seed) {
    return (uint8_t)((idx * 17 + j * 31 + seed) & 255);
}
static long long now_ms(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}
static int file_exists(const char *p) { struct stat st; return stat(p, &st) == 0; }
static int load_file(const char *path, char **out, size_t *osz) {
    FILE *f = fopen(path, "r"); if (!f) return -1;
    fseek(f, 0, SEEK_END); long sz = ftell(f); rewind(f);
    char *b = malloc((size_t)sz + 1); if (!b) { fclose(f); return -1; }
    size_t r = fread(b, 1, (size_t)sz, f); b[r] = '\0'; fclose(f);
    if (out) *out = b; if (osz) *osz = r;
    return 0;
}
static void touch(const char *p) { FILE *f = fopen(p, "w"); if (f) { fprintf(f, "%lld\n", now_ms()); fclose(f); } }
static int extract_flow_id(const char *fd, char *buf, size_t sz) {
    const char *p = strstr(fd, "\"id\":"); if (!p) return -1;
    p += 5; while (*p == ' ') p++; if (*p != '"') return -1; p++;
    const char *e = strchr(p, '"'); if (!e) return -1;
    size_t len = (size_t)(e - p); if (len >= sz) len = sz - 1;
    memcpy(buf, p, len); buf[len] = '\0'; return 0;
}
static void dump_payload(const char *dir, const char *what, uint64_t idx,
                         const uint8_t *pl, uint32_t n) {
    char path[512];
    snprintf(path, sizeof(path), "%s/%s-%llu.bin", dir, what, (unsigned long long)idx);
    FILE *f = fopen(path, "wb");
    if (!f) { fprintf(stderr, "DUMP-FAIL %s idx=%llu (%s)\n", what,
                        (unsigned long long)idx, strerror(errno)); return; }
    size_t w = fwrite(pl, 1, n, f);
    int frc = fclose(f);
    if (w != n || frc != 0) { fprintf(stderr, "DUMP-INCOMPLETE %s idx=%llu wrote=%zu/%u\n",
                                      what, (unsigned long long)idx, w, n); return; }
    fprintf(stderr, "DUMP %s idx=%llu bytes=%u path=%s\n", what, (unsigned long long)idx, n, path);
}

/* ------------------------------------------------------------------ receiver */
static int role_receiver(int argc, char **argv) {
    /* receiver: [0]role [1]tag [2]outdir [3]domain [4]flowdef [5]tinfo_out [6]service [7]stopfile */
    if (argc < 7) { fprintf(stderr, "R usage error argc=%d\n", argc); return 2; }
    const char *outdir = argv[2], *domain = argv[3], *flowdef = argv[4];
    const char *tinfo_out = argv[5], *service = argv[6];
    const char *stopfile = (argc > 8 && argv[7][0] != '-') ? argv[7] : NULL;
    int no_adjust = 0;
    for (int i = 7; i < argc; i++) if (!strcmp(argv[i], "--no-adjust")) no_adjust = 1;
    char *fd = NULL;
    if (load_file(flowdef, &fd, NULL)) { fprintf(stderr, "R FATAL flow def missing\n"); return 2; }
    fprintf(stderr, "R start pid=%d euid=%d\n", (int)getpid(), (int)geteuid());
    mxlInstance inst = mxlCreateInstance(domain, "");
    if (!inst) { fprintf(stderr, "R FATAL instance\n"); return 2; }
    mxlFlowWriter w = NULL; mxlFlowConfigInfo cfg = {0}; bool created = false;
    mxlStatus st = mxlCreateFlowWriter(inst, fd, NULL, &w, &cfg, &created);
    if (st) { fprintf(stderr, "R FATAL writer %d\n", (int)st); return 2; }
    fprintf(stderr, "R flow created=%d ring=%u\n", created, cfg.discrete.grainCount);
    mxlFabricsInstance fi = NULL;
    st = mxlFabricsCreateInstance(inst, NULL, &fi);
    if (st) { fprintf(stderr, "R FATAL fabrics %d\n", (int)st); return 2; }
    mxlFabricsTarget tgt = NULL;
    st = mxlFabricsCreateTarget(fi, &tgt);
    if (st) { fprintf(stderr, "R FATAL target %d\n", (int)st); return 2; }
    mxlFabricsTargetConfig tc = {0};
    tc.version = MXL_FABRICS_API_VERSION;
    tc.interface.version = MXL_FABRICS_API_VERSION;
    tc.interface.provider = MXL_FABRICS_PROVIDER_VERBS;
    tc.interface.caps.version = MXL_FABRICS_API_VERSION;
    tc.interface.caps.flags = MXL_FABRICS_IFACE_CAP_BLOCKING_OPERATIONS |
                              MXL_FABRICS_IFACE_CAP_REMOTE_WRITE;
    tc.interface.address.node = "192.168.100.2";
    tc.interface.address.service = service;
    tc.writer = w;
    mxlFabricsTargetInfo tinfo = NULL;
    st = mxlFabricsTargetSetup(tgt, &tc, NULL, &tinfo);
    if (st) { fprintf(stderr, "R FATAL setup %d\n", (int)st); return 2; }
    /* publish target info through the explicit test-control channel (file) */
    size_t need = 0;
    st = mxlFabricsTargetInfoToString(tinfo, NULL, &need);
    if (st && st != MXL_ERR_INVALID_ARG) { fprintf(stderr, "R FATAL info size %d\n", (int)st); return 2; }
    char *buf = malloc(need + 1);
    size_t sz = need;
    st = mxlFabricsTargetInfoToString(tinfo, buf, &sz);
    if (st) { fprintf(stderr, "R FATAL info str %d\n", (int)st); return 2; }
    FILE *f = fopen(tinfo_out, "w");
    if (!f) { fprintf(stderr, "R FATAL tinfo write\n"); return 2; }
    fprintf(f, "%s", buf); fclose(f);
    char ready[600]; snprintf(ready, sizeof(ready), "%s.ready", tinfo_out);
    touch(ready);   /* readiness barrier marker (separate file; never clobber tinfo) */
    fprintf(stderr, "R target-listening node=192.168.100.2 service=%s\n", service);

    int commits = 0;
    long long deadline = now_ms() + 300000;
    while (now_ms() < deadline) {
        uint64_t gidx = 0;
        st = mxlFabricsTargetReadGrain(tgt, 200, &gidx);
        if (st == MXL_STATUS_OK) {
            mxlGrainInfo gi = {0}; gi.version = 2; gi.size = sizeof(mxlGrainInfo);
            uint8_t *pl = NULL;
            mxlStatus s2 = mxlFlowWriterOpenGrain(w, gidx, &gi, &pl);
            if (s2 == MXL_STATUS_OK) {
                uint32_t rawVS = gi.validSlices;
                if (!no_adjust && gi.validSlices == 0 && gi.totalSlices > 0) gi.validSlices = gi.totalSlices;
                s2 = mxlFlowWriterCommitGrain(w, &gi);
                fprintf(stderr, "R COMMIT idx=%llu rawVS=%u TS=%u adj=%d status=%d\n",
                        (unsigned long long)gidx, rawVS, gi.totalSlices,
                        (int)(rawVS == 0 && gi.validSlices != 0), (int)s2);
                if (s2 == MXL_STATUS_OK) {
                    commits++;
                    fprintf(stderr, "R committed=%d\n", commits);
                    if (stopfile) touch(stopfile);  /* signal committed-count available */
                }
            } else fprintf(stderr, "R OPENFAIL idx=%llu %d\n", (unsigned long long)gidx, (int)s2);
        } else if (st != MXL_ERR_TIMEOUT && st != MXL_ERR_NOT_READY) {
            fprintf(stderr, "R READ-ERR %d\n", (int)st);
        }
    }
    fprintf(stderr, "R done commits=%d\n", commits);
    if (tinfo) mxlFabricsFreeTargetInfo(tinfo);
    mxlFabricsDestroyTarget(fi, tgt);
    mxlFabricsDestroyInstance(fi);
    mxlReleaseFlowWriter(inst, w);
    mxlDestroyInstance(inst);
    free(fd);
    return 0;
}

/* ------------------------------------------------------------------ sender */
static int role_sender(int argc, char **argv) {
    /* sender tag outdir domain flowdef tinfo_in localnode base_idx n seed [stopfile] [--no-transfer] */
    if (argc < 10) { fprintf(stderr, "S usage error argc=%d\n", argc); return 2; }
    const char *outdir = argv[2], *domain = argv[3], *flowdef = argv[4];
    const char *tinfo_in = argv[5], *localnode = argv[6];
    uint64_t base = strtoull(argv[7], NULL, 10);
    int n = atoi(argv[8]);
    uint32_t seed = (uint32_t)strtoul(argv[9], NULL, 10);
    const char *stopfile = (argc > 10 && argv[10][0] != '-') ? argv[10] : NULL;
    int no_transfer = 0;
    int remove_after = -1;   /* legacy no-op placeholder */
    const char *probe_file = NULL;  /* T17A gate: after n queued AND this file appears -> RemoveTarget + 1 probe */
    int no_remove = 0;   /* T17B: probe on the EXISTING connection, no RemoveTarget */
    for (int i = 10; i < argc; i++) {
        if (!strcmp(argv[i], "--no-transfer")) no_transfer = 1;
        if (!strcmp(argv[i], "--no-remove")) no_remove = 1;
        if (!strcmp(argv[i], "--probe-file") && i + 1 < argc) probe_file = argv[i + 1];
    }
    int removed = 0, attempts_after_remove = 0;

    char *fd = NULL;
    if (load_file(flowdef, &fd, NULL)) { fprintf(stderr, "S FATAL flow def\n"); return 2; }
    fprintf(stderr, "S start pid=%d euid=%d base=%llu n=%d seed=%u\n",
            (int)getpid(), (int)geteuid(), (unsigned long long)base, n, seed);
    mxlInstance inst = mxlCreateInstance(domain, "");
    if (!inst) { fprintf(stderr, "S FATAL instance\n"); return 2; }
    mxlFlowWriter w = NULL; mxlFlowConfigInfo cfg = {0}; bool created = false;
    mxlStatus st = mxlCreateFlowWriter(inst, fd, NULL, &w, &cfg, &created);
    if (st) { fprintf(stderr, "S FATAL writer %d\n", (int)st); return 2; }
    char flowId[64]; extract_flow_id(fd, flowId, sizeof(flowId));
    mxlFlowReader rd = NULL;
    st = mxlCreateFlowReader(inst, flowId, "", &rd);
    if (st) { fprintf(stderr, "S FATAL reader %d\n", (int)st); return 2; }

    /* publish n grains (deterministic per (idx,seed)); with --probe-file, n+1 (last reserved for probe) */
    uint32_t sizes[64] = {0};
    int publish_n = probe_file ? n + 1 : n;
    if (publish_n > 64) return 2;
    for (int i = 0; i < publish_n; i++) {
        uint64_t idx = base + i;
        mxlGrainInfo gi = {0}; gi.version = 2; gi.size = sizeof(mxlGrainInfo); gi.index = idx;
        uint8_t *pl = NULL;
        st = mxlFlowWriterOpenGrain(w, idx, &gi, &pl);
        if (st) { fprintf(stderr, "S FATAL open %d\n", (int)st); return 2; }
        for (uint32_t j = 0; j < gi.grainSize; j++) pl[j] = payload_byte(idx, j, seed);
        gi.validSlices = gi.totalSlices;
        st = mxlFlowWriterCommitGrain(w, &gi);
        if (st) { fprintf(stderr, "S FATAL commit %d\n", (int)st); return 2; }
        sizes[i] = gi.totalSlices;
        fprintf(stderr, "S SENT idx=%llu grainSize=%u slices=%u\n",
                (unsigned long long)idx, gi.grainSize, gi.totalSlices);
    }

    mxlFabricsInstance fi = NULL;
    st = mxlFabricsCreateInstance(inst, NULL, &fi);
    if (st) { fprintf(stderr, "S FATAL fabrics %d\n", (int)st); return 2; }
    mxlFabricsInitiator ini = NULL;
    st = mxlFabricsCreateInitiator(fi, &ini);
    if (st) { fprintf(stderr, "S FATAL initiator %d\n", (int)st); return 2; }
    mxlFabricsInitiatorConfig ic = {0};
    ic.version = MXL_FABRICS_API_VERSION;
    ic.interface.version = MXL_FABRICS_API_VERSION;
    ic.interface.provider = MXL_FABRICS_PROVIDER_VERBS;
    ic.interface.caps.version = MXL_FABRICS_API_VERSION;
    ic.interface.caps.flags = MXL_FABRICS_IFACE_CAP_BLOCKING_OPERATIONS |
                              MXL_FABRICS_IFACE_CAP_REMOTE_WRITE;
    ic.interface.address.node = localnode;
    ic.interface.address.service = NULL;
    ic.reader = rd;
    st = mxlFabricsInitiatorSetup(ini, &ic, NULL);
    if (st) { fprintf(stderr, "S FATAL init setup %d\n", (int)st); return 2; }
    fprintf(stderr, "S initiator-ready\n");

    mxlFabricsTargetInfo tinfo = NULL;
    int have_tinfo = 0;
    if (load_file(tinfo_in, NULL, NULL) == 0) {
        char *tb = NULL; size_t tsz = 0; load_file(tinfo_in, &tb, &tsz);
        st = mxlFabricsTargetInfoFromString(tb, &tinfo);
        if (st == MXL_STATUS_OK && tinfo) {
            st = mxlFabricsInitiatorAddTarget(ini, tinfo);
            have_tinfo = (st == MXL_STATUS_OK);
            fprintf(stderr, "S ADDTARGET status=%d have=%d\n", (int)st, have_tinfo);
        } else {
            fprintf(stderr, "S TINFO-PARSE-FAIL status=%d (excluded-peer-without-info case)\n", (int)st);
        }
        free(tb);
    } else {
        fprintf(stderr, "S NO-TARGET-INFO (excluded-peer case: only address available)\n");
    }

    int connected = 0, queued = 0, pump = 0;
    long long t0 = now_ms(), deadline = t0 + 120000;
    int gate_fired = 0, probe_done = (probe_file == NULL);   /* probe lifecycle independent of queued<n */
    while (now_ms() < deadline && (!connected || queued < n || !probe_done)) {
        mxlStatus ps = mxlFabricsInitiatorMakeProgressNonBlocking(ini);
        if (ps == MXL_STATUS_OK) connected = 1;
        else if (ps != MXL_ERR_NOT_READY && ps != MXL_ERR_INVALID_STATE) {
            fprintf(stderr, "S PROGRESS-ERR %d\n", (int)ps);
            if (ps == MXL_ERR_TIMEOUT || ps == MXL_ERR_INTERRUPTED) break;
        }
        /* T17A/B gate: once n session-A grains are queued AND the orchestrator file
           appears: (A) RemoveTarget then ONE probe grain (base+n);
           (B) with --no-remove: probe on the existing connection (no lifecycle op). */
        if (probe_file && !gate_fired && queued >= n && file_exists(probe_file)) {
            if (no_remove) {
                fprintf(stderr, "S PROBE-GATE no-lifecycle-op (existing-connection leg)\n");
            } else {
                st = mxlFabricsInitiatorRemoveTarget(ini, tinfo);
                removed = 1;
                fprintf(stderr, "S REMOVETARGET status=%d (local op; probe follows after A-delivery verified)\n", (int)st);
            }
            gate_fired = 1;
        }
        if (connected && !no_transfer && queued < n) {
            st = mxlFabricsInitiatorTransferGrain(ini, base + queued, 0, sizes[queued]);
            if (st == MXL_STATUS_OK) { queued++;
                fprintf(stderr, "S QUEUED %d/%d idx=%llu\n", queued, n,
                        (unsigned long long)(base + queued - 1)); }
            else if (st != MXL_ERR_NOT_READY && st != (mxlStatus)11)
                fprintf(stderr, "S TRANSFER-ERR %d idx=%llu\n", (int)st,
                        (unsigned long long)(base + queued));
        }
        /* probe phase: exactly one transfer attempt at index base+n, bounded retries */
        if (gate_fired && !probe_done) {
            st = mxlFabricsInitiatorTransferGrain(ini, base + n, 0, sizes[n]);
            attempts_after_remove++;
            if (st == MXL_STATUS_OK) { queued++; probe_done = 1;
                fprintf(stderr, "S QUEUED probe idx=%llu %s attempts=%d\n",
                        (unsigned long long)(base + n), removed ? "AFTER-REMOVE" : "EXISTING-CONN",
                        attempts_after_remove); }
            else if (st != MXL_ERR_NOT_READY && st != (mxlStatus)11) {
                probe_done = 1;
                fprintf(stderr, "S PROBE-REJECTED idx=%llu status=%d %s attempts=%d\n",
                        (unsigned long long)(base + n), (int)st,
                        removed ? "AFTER-REMOVE" : "EXISTING-CONN", attempts_after_remove); }
            else if (now_ms() > t0 + 100000) { probe_done = 1;
                fprintf(stderr, "S PROBE-ATTEMPTS-EXHAUSTED status=NOT_READY %s attempts=%d\n",
                        removed ? "AFTER-REMOVE" : "EXISTING-CONN", attempts_after_remove); }
        }
        if (no_transfer && connected && ++pump > 500) break;
        usleep(500);
    }
    fprintf(stderr, "S connected=%d queued=%d/%d gate_fired=%d probe_done=%d elapsed_ms=%lld\n",
            connected, queued, n, gate_fired, probe_done, now_ms() - t0);

    /* stay alive until stopfile (verification must finish with endpoints live) */
    if (stopfile) {
        /* gate may not have fired inside the main loop (early loop exit):
           wait for it HERE, endpoints still live, then execute the probe. */
        if (probe_file && !gate_fired) {
            long long gd = now_ms() + 150000;
            fprintf(stderr, "S HOLD-GATE waiting for probe gate\n");
            while (!file_exists(probe_file) && now_ms() < gd && !file_exists(stopfile)) {
                mxlFabricsInitiatorMakeProgressNonBlocking(ini);
                usleep(20000);
            }
            if (file_exists(probe_file)) {
                if (no_remove) fprintf(stderr, "S PROBE-GATE no-lifecycle-op (existing-connection leg)\n");
                else { st = mxlFabricsInitiatorRemoveTarget(ini, tinfo); removed = 1;
                       fprintf(stderr, "S REMOVETARGET status=%d (post-loop gate)\n", (int)st); }
                gate_fired = 1;
                long long pd = now_ms() + 30000; int done = 0;
                while (now_ms() < pd && !done) {
                    mxlFabricsInitiatorMakeProgressNonBlocking(ini);
                    st = mxlFabricsInitiatorTransferGrain(ini, base + n, 0, sizes[n]);
                    if (st == MXL_STATUS_OK) { queued++; done = 1;
                        fprintf(stderr, "S QUEUED probe idx=%llu %s\n", (unsigned long long)(base + n),
                                removed ? "AFTER-REMOVE" : "EXISTING-CONN"); }
                    else if (st != MXL_ERR_NOT_READY && st != (mxlStatus)11) { done = 1;
                        fprintf(stderr, "S PROBE-REJECTED idx=%llu status=%d\n",
                                (unsigned long long)(base + n), (int)st); }
                    usleep(5000);
                }
                if (!done) fprintf(stderr, "S PROBE-ATTEMPTS-EXHAUSTED\n");
                probe_done = done;
                /* keep pumping so target can drain completions while verifier runs */
                long long keep = now_ms() + 60000;
                while (!file_exists(stopfile) && now_ms() < keep) {
                    mxlFabricsInitiatorMakeProgressNonBlocking(ini);
                    usleep(20000);
                }
            }
        }
        long long sd = now_ms() + 180000;
        while (!file_exists(stopfile) && now_ms() < sd) usleep(50000);
        fprintf(stderr, "S released=%d elapsed=%lldms\n", file_exists(stopfile), now_ms() - t0);
    }
    fprintf(stderr, "S RESULT connected=%d queued=%d\n", connected, queued);
    if (tinfo) mxlFabricsFreeTargetInfo(tinfo);
    mxlFabricsDestroyInitiator(fi, ini);
    mxlFabricsDestroyInstance(fi);
    mxlReleaseFlowReader(inst, rd);
    mxlReleaseFlowWriter(inst, w);
    mxlDestroyInstance(inst);
    free(fd);
    return connected && (no_transfer || (probe_file ? queued >= n + 1 : queued == n) ||
                         (probe_file && removed && queued == n)) ? 0 : 1;
}

/* ------------------------------------------------------------------ verify */
static int role_verify(int argc, char **argv) {
    /* verify outdir domain flowid base_idx n seed */
    if (argc < 7) return 2;
    const char *outdir = argv[1], *domain = argv[2], *flowId = argv[3];
    uint64_t base = strtoull(argv[4], NULL, 10);
    int n = atoi(argv[5]);
    uint32_t seed = (uint32_t)strtoul(argv[6], NULL, 10);
    fprintf(stderr, "V start pid=%d domain=%s flow=%s base=%llu n=%d seed=%u\n",
            (int)getpid(), domain, flowId, (unsigned long long)base, n, seed);
    mxlInstance inst = mxlCreateInstance(domain, "");
    if (!inst) { fprintf(stderr, "V FATAL instance\n"); return 2; }
    mxlFlowReader r = NULL;
    mxlStatus st = mxlCreateFlowReader(inst, flowId, "", &r);
    if (st) { fprintf(stderr, "V RESULT reader=%d\n", (int)st); mxlDestroyInstance(inst); return 2; }
    int ok = 0, errs = 0, bad = 0;
    for (int i = 0; i < n; i++) {
        uint64_t idx = base + i;
        mxlGrainInfo gi = {0}; gi.version = 2; gi.size = sizeof(mxlGrainInfo);
        uint8_t *pl = NULL;
        st = mxlFlowReaderGetGrain(r, idx, 5000000000ULL, &gi, &pl);
        if (st != MXL_STATUS_OK) { errs++;
            fprintf(stderr, "V READ idx=%llu status=%d\n", (unsigned long long)idx, (int)st); continue; }
        if (!pl || gi.grainSize == 0 || gi.grainSize > 64u * 1024 * 1024) { errs++;
            fprintf(stderr, "V READ idx=%llu INVALID-PAYPTR-OR-SIZE %u\n",
                    (unsigned long long)idx, gi.grainSize); continue; }
        dump_payload(outdir, "rx", idx, pl, gi.grainSize);
        int mism = 0, allzero = 1;
        for (uint32_t j = 0; j < gi.grainSize; j++) {
            if (pl[j] != payload_byte(idx, j, seed)) mism++;
            if (pl[j]) allzero = 0;
        }
        int slcok = (gi.validSlices == gi.totalSlices && gi.totalSlices > 0);
        fprintf(stderr, "V IDX idx=%llu grainSize=%u slices=%u/%u mismatches=%d allzero=%d\n",
                (unsigned long long)idx, gi.grainSize, gi.validSlices, gi.totalSlices, mism, allzero);
        if (mism == 0 && !allzero && slcok) ok++; else bad++;
    }
    fprintf(stderr, "V RESULT ok=%d err=%d bad=%d\n", ok, errs, bad);
    mxlReleaseFlowReader(inst, r);
    mxlDestroyInstance(inst);
    return (ok == n && errs == 0 && bad == 0) ? 0 : 1;
}

int main(int argc, char **argv) {
    setvbuf(stderr, NULL, _IONBF, 0);
    if (argc < 2) { fprintf(stderr, "role?\n"); return 2; }
    /* every role sees argv[0] = role word */
    if (!strcmp(argv[1], "receiver")) return role_receiver(argc - 1, argv + 1);
    if (!strcmp(argv[1], "sender"))   return role_sender(argc - 1, argv + 1);
    if (!strcmp(argv[1], "verify"))   return role_verify(argc - 1, argv + 1);
    fprintf(stderr, "unknown role %s\n", argv[1]);
    return 2;
}
