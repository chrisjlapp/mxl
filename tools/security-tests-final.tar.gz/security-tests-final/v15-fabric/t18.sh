#!/usr/bin/env bash
# T18: bounded concurrent-target resource admission + recovery (verbs).
# PRE-DECLARED BUDGET (set before running; do not tune mid-campaign):
#   steps: 1,2,4,8,16 concurrent targets (receiver processes), one sender each
#   per-target: 1 grain (3 transfers each, small n to isolate resource effects)
#   stop condition: any target startup failure, any leg delivery failure,
#     OR host budget: total RSS of target processes > 8 GB, OR fd total > 80000,
#     OR free memory < 2 GB. Max 16 (bounded).
# Recovery: after teardown, one full authorized pair transfer must succeed.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BASE=/home/chlapp/projects/mxl-security-baseline
export LD_LIBRARY_PATH=/opt/libfabric121/lib:$BASE/build/lib:$BASE/build/lib/fabrics/ofi
STEPS="${T18_STEPS:-1 2 4 8 16}"
MAX_RSS_KB=$((8*1024*1024)); MAX_FDS=80000; MIN_FREE_KB=$((2*1024*1024))
RUN=$HERE/runs/t18-$(date +%H%M%S)
rm -rf "$RUN"; mkdir -p "$RUN"
FLOWID=$(python3 -c "import json;print(json.load(open('/tmp/mxl-target-flow.json'))['id'])")
log() { echo "$1" | tee -a "$RUN/t18.log"; }
rdma_res() { rdma res show 2>/dev/null | grep -E "pd [0-9]+ cq" | sort; }

budget_ok() {  # $1 = tag prefix for counting
  local rss fds free
  rss=$(for p in $(pgrep -f "v15-roles (receiver|sender) t18"); do awk '/VmRSS/{s+=$2} END{print s+0}' /proc/$p/status 2>/dev/null; done | awk '{t+=$1} END{print t+0}')
  fds=$(for p in $(pgrep -f "v15-roles (receiver|sender) t18"); do ls /proc/$p/fd 2>/dev/null | wc -l; done | awk '{t+=$1} END{print t+0}')
  free=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
  RDMA=$(cat /sys/class/infiniband/rocep1s0f0/hw_counters/* 2>/dev/null | head -1)
  echo "  budget: targets_rss_kb=$rss fds=$fds mem_available_kb=$free" >> "$RUN/t18.log"
  [ "$rss" -lt "$MAX_RSS_KB" ] && [ "$fds" -lt "$MAX_FDS" ] && [ "$free" -gt "$MIN_FREE_KB" ]
}

for STEP in $STEPS; do
  log "=== STEP targets=$STEP $(date -Is) ==="
  rdma_res > "$RUN/rdma-before-$STEP.txt"; log "  rdma resources before: $(awk '{t+=$4} END {printf "qps=%s", t}' FS=' ' <(awk '/qp/{print $0}' "$RUN/rdma-before-$STEP.txt") 2>/dev/null || cat "$RUN/rdma-before-$STEP.txt" | head -1)"
  declare -a RPID SPID
  ok_start=1
  # launch STEP receivers (fresh processes), each own domain+service
  for i in $(seq 1 $STEP); do
    D=/dev/shm/mxl-v15mp-t18r${STEP}i$i; rm -rf $D; mkdir -p $D
    SD=$RUN/r${STEP}i$i; rm -rf $SD; mkdir -p $SD
    "$HERE/v15-roles" receiver t18r${STEP}i$i $SD $D /tmp/mxl-target-flow.json $SD/tinfo.json $((7500+STEP*100+i)) > $SD/receiver.log 2>&1 &
    RPID[$i]=$!
  done
  # readiness barrier for all
  for i in $(seq 1 $STEP); do
    ready=0
    for _ in $(seq 1 300); do [ -e "$RUN/r${STEP}i$i/tinfo.json.ready" ] && ready=1 && break; kill -0 ${RPID[$i]} 2>/dev/null || break; sleep 0.1; done
    if [ $ready -ne 1 ]; then
      alive=0; kill -0 ${RPID[$i]} 2>/dev/null && alive=1
      log "target $i/$STEP startup-FAIL alive=$alive exit-recorded=$(wait ${RPID[$i]} 2>/dev/null; echo $?)"
      grep -m2 "R FATAL\|rdma_bind\|Failed" "$RUN/r${STEP}i$i/receiver.log" | sed 's/^/    /' | tee -a "$RUN/t18.log"
      ok_start=0
    fi
  done
  if [ $ok_start -eq 0 ]; then log "STEP $STEP: STARTUP FAILURE — stop condition hit (record, teardown, no inference)";
    for i in $(seq 1 $STEP); do kill -TERM ${RPID[$i]} 2>/dev/null; done
    for i in $(seq 1 $STEP); do wait ${RPID[$i]} 2>/dev/null; done
    break
  fi
  # overlapping lifetime proof: capture start+alive state of all PIDs before senders finish
  for i in $(seq 1 $STEP); do
    echo "$(date +%s.%N) start pid=${RPID[$i]}" >> "$RUN/overlap-$STEP.txt"
  done
  # launch one sender per receiver (1 grain each) — legitimate workload
  for i in $(seq 1 $STEP); do
    SD=$RUN/r${STEP}i$i
    DS=/dev/shm/mxl-v15mp-t18s${STEP}i$i; rm -rf $DS; mkdir -p $DS
    "$HERE/v15-roles" sender t18s${STEP}i$i $SD $DS /tmp/mxl-target-flow.json $SD/tinfo.json 192.168.100.1 $((537110$((STEP))0$((i*1000)))) 1 51 $SD/done > $SD/sender.log 2>&1 &
    SPID[$i]=$!
  done
  # monitor overlapping lifetimes during transfer; ENFORCE budget DURING the step
  breach=""
  for w in $(seq 1 40); do
    alive=$(for i in $(seq 1 $STEP); do kill -0 ${RPID[$i]} 2>/dev/null && echo x; done | wc -l)
    alives=$(for i in $(seq 1 $STEP); do kill -0 ${SPID[$i]} 2>/dev/null && echo x; done | wc -l)
    echo "$(date +%s.%N) receivers_alive=$alive/$STEP senders_alive=$alives/$STEP" >> "$RUN/overlap-$STEP.txt"
    rss=$(for p in $(pgrep -f "v15-roles (receiver|sender) t18"); do awk '/VmRSS/{print $2}' /proc/$p/status 2>/dev/null; done | awk '{t+=$1} END{print t+0}')
    fds=$(for p in $(pgrep -f "v15-roles (receiver|sender) t18"); do ls /proc/$p/fd 2>/dev/null | wc -l; done | awk '{t+=$1} END{print t+0}')
    qp=$(rdma res show qp 2>/dev/null | grep -c "^")
    free=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
    echo "$(date +%s.%N) inflight rss_kb=$rss fds=$fds rdma_qp=$qp mem_available_kb=$free" >> "$RUN/overlap-$STEP.txt"
    if [ "$rss" -ge "$MAX_RSS_KB" ] || [ "$fds" -ge "$MAX_FDS" ] || [ "$free" -le "$MIN_FREE_KB" ]; then
      breach="budget rss=$rss fds=$fds free=$free"; break
    fi
    if [ "$alive" -lt "$STEP" ]; then breach="target-process-died alive=$alive/$STEP"; break; fi
    sleep 0.25
  done
  [ -n "$breach" ] && log "  IN-STEP STOP-CONDITION: $breach"
  # verify every leg at receiver
  deliv=0; fail=0
  for i in $(seq 1 $STEP); do
    SD=$RUN/r${STEP}i$i
    D=/dev/shm/mxl-v15mp-t18r${STEP}i$i
    timeout 40 "$HERE/v15-roles" verify $SD $D "$FLOWID" $((537110$((STEP))0$((i*1000)))) 1 51 > $SD/verify.log 2>&1
    rc=$?
    touch $SD/done
    if [ $rc -eq 0 ]; then deliv=$((deliv+1)); else fail=$((fail+1))
      log "  leg $i DELIVERY-FAIL rc=$rc — stop condition (per header)"; tail -2 $SD/verify.log | sed 's/^/    /' | tee -a "$RUN/t18.log"
    fi
  done
  for i in $(seq 1 $STEP); do wait ${SPID[$i]} 2>/dev/null; done
  for i in $(seq 1 $STEP); do kill -TERM ${RPID[$i]} 2>/dev/null; wait ${RPID[$i]} 2>/dev/null; done
  # memory of ONE receiver at peak (from /proc while alive is captured below for last step)
  rdma_res > "$RUN/rdma-after-$STEP.txt"
  log "  rdma resources after step (device pd/cq/qp/mr lines): $(wc -l < "$RUN/rdma-after-$STEP.txt") device lines"
  ov=$(grep -c "receivers_alive=$STEP/$STEP" "$RUN/overlap-$STEP.txt")
  log "STEP $STEP: start_ok=yes delivered=$deliv/$STEP failed=$fail overlapping_windows_with_all_targets=$ov"
  budget_ok || { log "STOP-CONDITION: host budget reached at step $STEP"; break; }
done

# teardown resources, then RECOVERY: full authorized pair transfer must succeed
sleep 2
log "=== RECOVERY (post-teardown authorized transfer) $(date -Is) ==="
bash "$HERE/v15_pair.sh" t18-rec "$RUN/recovery" 53711990000 3 55 7699 >> "$RUN/t18.log" 2>&1
REC=$?
grep "^V RESULT" "$RUN/recovery/verify.log" 2>/dev/null | sed 's/^/RECOVERY: /' | tee -a "$RUN/t18.log"
log "T18-DONE recovery_rc=$REC $(date -Is)"
