#!/usr/bin/env bash
# T16-C: excluded peer WITH copied target information (disclosure/reuse scenario).
# Steps: authorized control (before) -> receiver up -> excluded peer with copied tinfo -> receiver verify -> authorized control (after).
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BASE=/home/chlapp/projects/mxl-security-baseline
export LD_LIBRARY_PATH=/opt/libfabric121/lib:$BASE/build/lib:$BASE/build/lib/fabrics/ofi
REP=$1
RUN=$HERE/runs/t16c-$REP-$(date +%H%M%S)
rm -rf "$RUN"; mkdir -p "$RUN"
FLOWID=$(python3 -c "import json;print(json.load(open('/tmp/mxl-target-flow.json'))['id'])")

echo "== 1. authorized control BEFORE =="
bash "$HERE/v15_pair.sh" t16c-pre$REP "$RUN/pre" 53710$((20+REP))00000 3 11 712$REP > "$RUN/pre.out" 2>&1
grep -E "^V RESULT|^S RESULT" "$RUN"/pre/*.log | sed 's/^/PRE: /'

echo "== 2. receiver for disclosure target =="
rm -rf /dev/shm/mxl-v15mp-t16cd$REP-r; mkdir -p /dev/shm/mxl-v15mp-t16cd$REP-r
"$HERE/v15-roles" receiver t16cd$REP "$RUN" /dev/shm/mxl-v15mp-t16cd$REP-r /tmp/mxl-target-flow.json "$RUN/tinfo.json" 713$REP > "$RUN/receiver.log" 2>&1 &
RPID=$!
for i in $(seq 1 200); do [ -e "$RUN/tinfo.json.ready" ] && break; sleep 0.1; done
[ -e "$RUN/tinfo.json.ready" ] || { echo "BARRIER-FAIL"; kill $RPID; exit 3; }
# TINFO-DISCLOSURE: copy exact bytes of the legitimate target info to the excluded peer dir
cp "$RUN/tinfo.json" "$RUN/tinfo-copy-to-excluded.json"
sha256sum "$RUN/tinfo.json" | awk '{print "tinfo-sha256="$1}' > "$RUN/tinfo-hash.txt"
cat "$RUN/tinfo-hash.txt"

echo "== 3. EXCLUDED peer attempt with copied target info =="
rm -rf /dev/shm/mxl-v15mp-t16cx$REP-s; mkdir -p /dev/shm/mxl-v15mp-t16cx$REP-s
EXBASE=$((53710$((20+REP))0000 + 500000))   # non-colliding indices, distinguishable seed 99
rm -f "$RUN/excluded-held"
timeout 120 "$HERE/v15-roles" sender t16cx$REP "$RUN" /dev/shm/mxl-v15mp-t16cx$REP-s /tmp/mxl-target-flow.json "$RUN/tinfo-copy-to-excluded.json" 192.168.100.1 "$EXBASE" 3 99 "$RUN/excluded-held" > "$RUN/excluded.log" 2>&1 &
XPID=$!
# keep the excluded endpoint alive while observing target-side effects (10 s)
sleep 10
echo "== 4. receiver-side attribution: did excluded payload land? (excluded endpoint still live) =="
FLOWID=$(python3 -c "import json;print(json.load(open('/tmp/mxl-target-flow.json'))['id'])")
"$HERE/v15-roles" verify "$RUN" /dev/shm/mxl-v15mp-t16cd$REP-r "$FLOWID" "$EXBASE" 3 99 > "$RUN/verify-excluded.log" 2>&1
echo "verify-excluded rc=$? (0 = UNAUTHORIZED DELIVERY occurred)"
grep -E "^V RESULT|^V IDX" "$RUN/verify-excluded.log" | sed 's/^/EXCL-RX: /'
touch "$RUN/excluded-held"
wait $XPID; echo "excluded-sender rc=$?"
grep -E "^S RESULT|^S QUEUED|^S connected|^S ADDTARGET" "$RUN/excluded.log" | head -6

echo "== 5. authorized control AFTER =="
bash "$HERE/v15_pair.sh" t16c-post$REP "$RUN/post" 53710$((20+REP))05000 3 12 714$REP > "$RUN/post.out" 2>&1
grep -E "^V RESULT" "$RUN"/post/*.log | sed 's/^/POST: /'

kill -TERM $RPID 2>/dev/null; wait $RPID 2>/dev/null
grep -cE "^R COMMIT" "$RUN/receiver.log" | awk '{print "receiver-commits="$1}'
echo "T16C-DONE rep=$REP"
