#!/usr/bin/env bash
# T16-B: excluded peer WITHOUT target information.
# Threat model: peer knows only the target's advertised node:service (address disclosure),
# and has no valid serialized TargetInfo. Attempt the access available under that model:
#  (i) initiator without any AddTarget: progress/queue attempts must fail;
#  (ii) forged/garbage TargetInfo string: deserialize must fail;
#  (iii) confirm receiver storage untouched (verify at excluded indices).
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BASE=/home/chlapp/projects/mxl-security-baseline
export LD_LIBRARY_PATH=/opt/libfabric121/lib:$BASE/build/lib:$BASE/build/lib/fabrics/ofi
REP=$1
RUN=$HERE/runs/t16b-$REP-$(date +%H%M%S)
rm -rf "$RUN"; mkdir -p "$RUN"
FLOWID=$(python3 -c "import json;print(json.load(open('/tmp/mxl-target-flow.json'))['id'])")

# receiver up on its own service; excluded peer has NO valid tinfo
rm -rf /dev/shm/mxl-v15mp-t16bd$REP-r; mkdir -p /dev/shm/mxl-v15mp-t16bd$REP-r
"$HERE/v15-roles" receiver t16bd$REP "$RUN" /dev/shm/mxl-v15mp-t16bd$REP-r /tmp/mxl-target-flow.json "$RUN/tinfo.json" 716$REP > "$RUN/receiver.log" 2>&1 &
RPID=$!
for i in $(seq 1 200); do [ -e "$RUN/tinfo.json.ready" ] && break; sleep 0.1; done
[ -e "$RUN/tinfo.json.ready" ] || { echo "BARRIER-FAIL"; kill $RPID; exit 3; }
# the peer dir gets NO tinfo at all, plus a deliberately corrupt copy for case (ii)
echo '{"not":"a-valid-serialized-target-info"}' > "$RUN/tinfo-forged.json"

EXBASE=$((53710$((30+REP))0000 + 500000))
echo "== (i) attempt without any target info =="
rm -rf /dev/shm/mxl-v15mp-t16bx$REP-s; mkdir -p /dev/shm/mxl-v15mp-t16bx$REP-s
timeout 45 "$HERE/v15-roles" sender t16bx$REP "$RUN" /dev/shm/mxl-v15mp-t16bx$REP-s /tmp/mxl-target-flow.json /nonexistent-tinfo.json 192.168.100.1 "$EXBASE" 3 97 "$RUN/hold-i" > "$RUN/excluded-noinfo.log" 2>&1
echo "rc(no-info)=$?"
grep -E "^S NO-TARGET-INFO|^S RESULT|^S PROGRESS-ERR" "$RUN/excluded-noinfo.log" | head -5

echo "== (ii) attempt with forged/garbage target info =="
rm -rf /dev/shm/mxl-v15mp-t16by$REP-s; mkdir -p /dev/shm/mxl-v15mp-t16by$REP-s
timeout 45 "$HERE/v15-roles" sender t16by$REP "$RUN" /dev/shm/mxl-v15mp-t16by$REP-s /tmp/mxl-target-flow.json "$RUN/tinfo-forged.json" 192.168.100.1 "$EXBASE" 3 96 "$RUN/hold-ii" > "$RUN/excluded-forged.log" 2>&1
echo "rc(forged)=$?"
grep -E "^S TINFO-PARSE-FAIL|^S RESULT" "$RUN/excluded-forged.log" | head -4

echo "== (iii) receiver-side: nothing should have landed =="
"$HERE/v15-roles" verify "$RUN" /dev/shm/mxl-v15mp-t16bd$REP-r "$FLOWID" "$EXBASE" 3 97 > "$RUN/verify-excluded.log" 2>&1
echo "verify rc=$? (nonzero = no unauthorized payload)"
grep -E "^V RESULT|^V IDX" "$RUN/verify-excluded.log" | tail -4
kill -TERM $RPID 2>/dev/null; wait $RPID 2>/dev/null
grep -cE "^R COMMIT" "$RUN/receiver.log" | awk '{print "receiver-commits="$1}'
echo "T16B-DONE rep=$REP"
