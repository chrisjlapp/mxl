#!/usr/bin/env python3
"""Package evidence: runtime-loaded library maps from live role processes + sha256 of
each mapped MXL/fabric library. Writes runs/maps-evidence/ (goes into the archive)."""
import hashlib, os, subprocess, sys, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
OUT = HERE / "runs" / "maps-evidence"
OUT.mkdir(parents=True, exist_ok=True)
BASE = "/home/chlapp/projects/mxl-security-baseline"
os.environ["LD_LIBRARY_PATH"] = f"/opt/libfabric121/lib:{BASE}/build/lib:{BASE}/build/lib/fabrics/ofi"
import uuid
flow = "/tmp/mxl-target-flow.json"
dom_r = "/dev/shm/mxl-v15mp-mapproof-r"; dom_s = "/dev/shm/mxl-v15mp-mapproof-s"
subprocess.run(["rm", "-rf", dom_r, dom_s]); os.makedirs(dom_r); os.makedirs(dom_s)
tinfo = str(OUT / "tinfo.json")
svc = 7999
rec = subprocess.Popen([str(HERE/"v15-roles"), "receiver", "mapproof", str(OUT), dom_r, flow, tinfo, str(svc)],
                       stdout=open(OUT/"receiver.log", "w"), stderr=subprocess.STDOUT)
for _ in range(200):
    if Path(tinfo + ".ready").exists(): break
    time.sleep(0.1)
send = subprocess.Popen([str(HERE/"v15-roles"), "sender", "mapproofs", str(OUT), dom_s, flow, tinfo,
                         "192.168.100.1", str(53712990000), "3", "9", str(OUT/"hold")],
                        stdout=open(OUT/"sender.log", "w"), stderr=subprocess.STDOUT)
time.sleep(2.0)
report = {"receiver": {"pid": rec.pid, "cmdline": open(f"/proc/{rec.pid}/cmdline").read().replace("\0", " ") if Path(f"/proc/{rec.pid}").exists() else None},
          "sender":   {"pid": send.pid, "cmdline": open(f"/proc/{send.pid}/cmdline").read().replace("\0", " ") if Path(f"/proc/{send.pid}").exists() else None}}
for who, p in (("receiver", rec.pid), ("sender", send.pid)):
    try:
        maps = open(f"/proc/{p}/maps").read()
    except FileNotFoundError:
        report[who]["maps"] = "<process gone>"; continue
    libs = sorted({l.split()[-1] for l in maps.splitlines()
                   if len(l.split()) == 6 and ("/" in l.split()[-1]) and (".so" in l.split()[-1])})
    mxl = [l for l in libs if "libmxl" in l or "libfabric" in l]
    report[who]["mapped_libs_all"] = libs
    report[who]["mapped_sdks"] = {l: hashlib.sha256(Path(l).read_bytes()).hexdigest() for l in mxl}
    report[who]["maps_snapshot"] = "".join(l + "\n" for l in maps.splitlines() if ".so" in l and "/" in l)
Path(OUT/"maps.json").write_text(__import__("json").dumps(report, indent=2))
Path(OUT/"hold").touch()
send.wait(timeout=60); rec.terminate(); rec.wait(timeout=30)
subprocess.run(["rm", "-rf", dom_r, dom_s])
print("maps evidence written to", OUT)
