#!/usr/bin/env python3
"""Aggregate V15 fabric-security runs (single-process, pair, T16/T17) into results.json + SUMMARY rows.
All observations come from executed run logs; missing/ambiguous evidence => INCONCLUSIVE, never pass."""
import glob, json, os, re, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"

def sha(p):
    import hashlib
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    return h.hexdigest()

def read_logs(run):
    out = {}
    for name in ("receiver.log", "receiverA.log", "receiverB.log", "sender.log", "senderA.log",
                 "verify.log", "verifyA.log", "verifyB.log", "verifyProbe.log", "verifyExisting.log",
                 "verifyExistingAfterTeardown.log", "stale.log",
                 "verifyStale.log", "verify-after-excluded.log", "verify-excluded.log", "excluded.log", "excluded-noinfo.log",
                 "excluded-forged.log", "run.log", "stdout.txt"):
        f = run / name
        if f.is_file(): out[name] = f.read_text(errors="replace")
    # nested pair dirs (pre/post)
    for sub in sorted(run.glob("*/")):
        if sub.name in ("sessA",): continue
        for name in ("receiver.log", "sender.log", "verify.log"):
            f = sub / name
            if f.is_file(): out[sub.name + "/" + name] = f.read_text(errors="replace")
    return out

def grepl(text, pat):
    return [m.group(0) for m in re.finditer(pat, text or "", re.M)]

def classify_single(tag_dir):
    logs = read_logs(tag_dir)
    v = grepl(logs.get("run.log", ""), r"=== VERDICT: delivery (\d)/3 \(err=(\d) bad=(\d)\)")
    ng = grepl(logs.get("run.log", ""), r"NEGATIVE CONTROL VERDICT: no-arrival=(\d)/3 \(leaks=(\d) errs=(\d)\)")
    pub = grepl(logs.get("run.log", ""), r"PUBLICATION-DISCIPLINE idx\d raw_validSlices=(\d+) raw_totalSlices=(\d+) adjusted=(\d) commit_status=(\d)")
    return {"delivery": v[0] if v else None, "negcontrol": ng[0] if ng else None, "publication": pub}

def classify_pair(tag_dir):
    logs = read_logs(tag_dir)
    def one(d):
        vv = grepl(logs.get(d + "/verify.log", ""), r"^V RESULT ok=(\d+) err=(\d+) bad=(\d+)")
        ss = grepl(logs.get(d + "/sender.log", ""), r"^S RESULT connected=(\d) queued=(\d)")
        rr = grepl(logs.get(d + "/receiver.log", ""), r"^R COMMIT idx=(\d+) rawVS=(\d+)")
        return {"verify": vv[0] if vv else "NOT-FOUND", "sender": ss[0] if ss else "NOT-FOUND", "commits": len(rr)}
    return {"pair": one(run_dir_name(tag_dir)) if False else None}

def run_dir_name(p): return p.name

results = []
# ---- single-process V15 controls
for d in sorted(RUNS.glob("v15-ctl-r*")):
    r = {"kind": "V15 control (single-process verbs)", "run": d.name}
    r.update(classify_single(d))
    caps = sorted(glob.glob(str(d / "rx-*.bin")))
    r["payload_captures"] = [os.path.basename(c) for c in caps]
    r["capture_sha256"] = {os.path.basename(c): sha(c) for c in caps}
    r["exit_code_recorded"] = 0 if r["delivery"] == "3/3 (err=0 bad=0)" else None
    results.append(r)
for d in sorted(RUNS.glob("v15-neg*")):
    r = {"kind": "V15 negative control (transfer disabled, fresh receiver storage)", "run": d.name}
    r.update(classify_single(d))
    results.append(r)
for d in sorted(RUNS.glob("v15-noadjust*")):
    r = {"kind": "V15 WITHOUT validSlices restoration (demo sequence)", "run": d.name}
    r.update(classify_single(d))
    results.append(r)
# ---- pair controls (fresh processes)
for d in sorted(RUNS.glob("mp-*/")):
    logs = read_logs(d)
    v = grepl(logs.get("verify.log", ""), r"^V RESULT ok=(\d+) err=(\d+) bad=(\d+)")
    s = grepl(logs.get("sender.log", ""), r"^S RESULT connected=(\d) queued=(\d)")
    c = grepl(logs.get("receiver.log", ""), r"^R COMMIT idx=(\d+) rawVS=(\d+) TS=(\d+) adj=(\d) status=(\d)")
    results.append({"kind": "V15 independent-process control", "run": d.name,
                    "verify": v[0] if v else "NOT-FOUND", "sender": s[0] if s else "NOT-FOUND",
                    "target_commits": [{"idx": x[0] if isinstance(x, list) else x} for x in c],
                    "commits_n": len(c),
                    "captures": [os.path.basename(x) for x in glob.glob(str(d / "rx-*.bin"))]})
# ---- T16B
for d in sorted(RUNS.glob("t16b-*/")):
    if not d.is_dir(): continue
    logs = read_logs(d)
    ni = grepl(logs.get("excluded-noinfo.log", ""), r"^S NO-TARGET-INFO|PROGRESS-ERR (\d+)|^S RESULT connected=(\d) queued=(\d)")
    fo = grepl(logs.get("excluded-forged.log", ""), r"^S TINFO-PARSE-FAIL status=(\d+)|^S RESULT connected=(\d) queued=(\d)")
    ve = grepl(logs.get("verify-excluded.log", ""), r"^V RESULT ok=(\d+) err=(\d+) bad=(\d+)")
    rc = grepl(logs.get("receiver.log", ""), r"^R COMMIT")
    results.append({"kind": "T16-B excluded peer without valid target info", "run": d.name,
                    "noinfo": ni, "forged": fo, "verify": ve[0] if ve else "NOT-FOUND",
                    "receiver_commits": len(rc),
                    "delivery": (bool(ve) and ve[0].startswith("V RESULT ok=3"))})
# ---- T16C
for d in sorted(RUNS.glob("t16c-*/")):
    if not d.is_dir(): continue
    logs = read_logs(d)
    def vr(t):
        m = re.search(r"V RESULT ok=(\d+) err=(\d+) bad=(\d+)", t or "")
        return m.group(0) if m else "NOT-FOUND"
    excl = grepl(logs.get("excluded.log", ""), r"^S QUEUED \d/3")
    rc = grepl(logs.get("receiver.log", ""), r"^R COMMIT")
    results.append({"kind": "T16-C excluded peer WITH copied target information", "run": d.name,
                    "pre": vr("\n".join(v for k, v in logs.items() if k.startswith("pre/") and k.endswith("verify.log"))),
                    "post": vr("\n".join(v for k, v in logs.items() if k.startswith("post/") and k.endswith("verify.log"))),
                    "excluded_queued_n": len(excl),
                    "excluded_rx_verify": vr(logs.get("verify-excluded.log", "")),
                    "receiver_commits": len(rc),
                    "tinfo_hash": (d / "tinfo-hash.txt").read_text().strip() if (d / "tinfo-hash.txt").is_file() else None,
                    "delivery": (bool(re.search(r"V RESULT ok=3", logs.get("verify-excluded.log", "") or "")))})
# ---- T17A
for d in sorted(RUNS.glob("t17a-*/")):
    if not d.is_dir(): continue
    logs = read_logs(d)
    a = re.search(r"V RESULT ok=(\d+)", logs.get("verifyA.log", "") or "")
    p = re.search(r"V RESULT ok=(\d+)", logs.get("verifyProbe.log", "") or "")
    rm = re.search(r"S REMOVETARGET status=(\d+)", logs.get("senderA.log", "") or "")
    pg = re.search(r"S PROBE-GATE", logs.get("senderA.log", "") or "")
    pq = re.search(r"S (QUEUED probe|PROBE-REJECTED|PROBE-ATTEMPTS-EXHAUSTED).*", logs.get("senderA.log", "") or "", re.M)
    cc = len(re.findall(r"^R COMMIT", logs.get("receiverA.log", "") or "", re.M))
    results.append({"kind": "T17-A stale target-info after RemoveTarget" + (" (existing-conn leg)" if pg else ""),
                    "run": d.name, "sessionA": a.group(0) if a else "NOT-FOUND",
                    "removetarget_status": rm.group(1) if rm else ("no-op (existing conn)" if pg else None),
                    "probe_sender": pq.group(0) if pq else "NOT-FOUND",
                    "probe_rx": p.group(0) if p else "NOT-FOUND", "receiver_commits": cc,
                    "probe_delivered": (bool(p) and p.group(1) == "1")})
# ---- T17B
for d in sorted(RUNS.glob("t17b-*/")):
    if not d.is_dir(): continue
    logs = read_logs(d)
    a = re.search(r"V RESULT ok=(\d+)", logs.get("verifyA.log", "") or "")
    e = re.search(r"V RESULT ok=(\d+)", logs.get("verifyExisting.log", "") or "")
    s = re.search(r"V RESULT ok=(\d+)", logs.get("verifyStale.log", "") or "")
    st = grepl(logs.get("stale.log", ""), r"^S RESULT connected=(\d) queued=(\d)|^S ADDTARGET status=(\d+)|^S connected.*")
    hashes = (d / "tinfo-hashes.txt").read_text() if (d / "tinfo-hashes.txt").is_file() else ""
    results.append({"kind": "T17-B target destroy+recreate; stale info reuse", "run": d.name,
                    "sessionA": a.group(0) if a else "NOT-FOUND",
                    "existing_conn_probe": e.group(0) if e else "NOT-FOUND",
                    "stale_probe_rx": s.group(0) if s else "NOT-FOUND",
                    "stale_sender": st[:4],
                    "tinfo_ab_differ": (len({l.split()[0] for l in hashes.splitlines() if l.split()}) == 2),
                    "stale_delivered": (bool(s) and s.group(1) == "1")})

# ---- T17-B v2 (same-port lifecycle-correct)
for d in sorted(RUNS.glob("t17bv2-*/")):
    if not d.is_dir(): continue
    logs = read_logs(d)
    def m(pat, f):
        r = re.search(pat, logs.get(f, "") or "")
        return r.group(0) if r else None
    quarantined = "QUARANTINED" in d.name
    results.append({"kind": "T17-B v2 destroy+recreate SAME port; authorized-B-then-stale", "run": d.name,
        "A": m(r"V RESULT ok=\d+", "verifyA.log"),
        "B_authorized": m(r"V RESULT ok=\d+", "verifyB.log"),
        "existing_after_teardown": m(r"V RESULT ok=\d+", "verifyExistingAfterTeardown.log"),
        "stale_tinfo": m(r"V RESULT ok=\d+", "verifyStale.log"),
        "stale_sender": [l for l in (logs.get("stale.log","") or "").splitlines() if l.startswith(("S RESULT","S connected","S ADDTARGET","S QUEUED","S TRANSFER"))][:4],
        "tinfo_ab": (d/"tinfo-hashes.txt").read_text() if (d/"tinfo-hashes.txt").is_file() else "",
        "quarantined": quarantined})

# ---- T18 stepped concurrency
for d in sorted(RUNS.glob("t18-*/")):
    if not d.is_dir(): continue
    logs = read_logs(d)
    tl = (d / "t18.log").read_text() if (d / "t18.log").is_file() else ""
    steps = re.findall(r"STEP (\d+): start_ok=(\w+) delivered=(\d+)/(\d+) failed=(\d+)", tl)
    recov = re.search(r"RECOVERY: V RESULT ok=(\d+)", tl)
    ov = {n: len(re.findall(f"receivers_alive={n}/"+str(n), (d/f"overlap-{n}.txt").read_text() if (d/f"overlap-{n}.txt").is_file() else "")) for n in (1,2,4,8,16)}
    results.append({"kind": "T18 bounded concurrent targets + recovery", "run": d.name,
                    "steps": steps, "recovery": recov.group(0) if recov else "NOT-FOUND",
                    "all_alive_sample_windows": ov})


Path(HERE / "results-aggregated.json").write_text(json.dumps(results, indent=2))
print(f"{len(results)} run groups aggregated")
for r in results:
    line = " | ".join(f"{k}={v}" for k, v in r.items() if k not in ("kind", "run", "capture_sha256", "payload_captures", "captures", "publication", "tinfo_hash"))
    print(f"[{r['kind']}] {r.get('run','?')}: {line}")
