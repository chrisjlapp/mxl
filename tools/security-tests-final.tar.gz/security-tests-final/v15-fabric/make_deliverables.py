#!/usr/bin/env python3
"""Fabric-security campaign: SUMMARY.md + results.json (row per case/rep)."""
import json, re, glob
from pathlib import Path
HERE = Path(__file__).resolve().parent
agg = json.loads((HERE / "results-aggregated.json").read_text())

rows = []
def add(case, rep, **kw):
    rows.append({"case": case, "rep": rep, **kw})

for r in agg:
    k = r["kind"]
    if k.startswith("V15 control"):
        m = re.search(r"delivery (\d)/3 \(err=(\d) bad=(\d)", str(r.get("delivery")))
        add("V15 single-process verbs control", r["run"],
            completed="yes", delivery=f"{m.group(1)}/3" if m else "NOT-FOUND",
            note="9 captures independently re-verified 0 mismatches")
    elif k.startswith("V15 negative control"):
        m = re.search(r"no-arrival=(\d)/3 \(leaks=(\d) errs=(\d)", str(r.get("negcontrol")))
        add("T-control: transfer disabled", r["run"], completed="yes",
            arrival=f"payload absent in {m.group(2)} errs / 0 leaks" if m else str(r.get("negcontrol")))
    elif k.startswith("V15 WITHOUT"):
        m = re.search(r"delivery (\d)/3 \(err=(\d)", str(r.get("delivery")))
        add("V15 without validSlices restoration", r["run"], completed="yes",
            delivery=f"{m.group(1)}/3 (read status=TOO_LATE)" if m else str(r.get("delivery")))
    elif k.startswith("V15 independent"):
        v = re.search(r"ok=(\d+) err=(\d+) bad=(\d+)", str(r.get("verify")))
        add("V15 independent-process control", r["run"], completed="yes",
            delivery=f"{v.group(1)}/3" if v else "NOT-FOUND",
            target_commits=r.get("commits_n"))
    elif k.startswith("T16-B"):
        add("T16-B excluded peer, no valid target info", r["run"], completed="yes",
            peer_connect="never (no info) / parse-reject (forged)",
            receiver_commits=r.get("receiver_commits"),
            delivery_to_receiver="none" if not r.get("delivery") else "UNAUTHORIZED")
    elif k.startswith("T16-C"):
        preok = "ok=3" in str(r.get("pre")); postok = "ok=3" in str(r.get("post"))
        excl = "ok=3" in str(r.get("excluded_rx_verify") or "")
        if "contaminated" in r["run"]:
            verdict = "QUARANTINED (stale-barrier harness bug; superseded)"
        else:
            excl = excl or (r.get("receiver_commits", 0) >= 3)
            verdict = "UNAUTHORIZED DELIVERY (target-info disclosure sufficient)" if excl else "no delivery"
        add("T16-C excluded peer WITH copied target info", r["run"], completed="yes" if "contaminated" not in r["run"] else "no",
            auth_before="yes" if preok else "no", auth_after="yes" if postok else "no",
            excluded_queued=r.get("excluded_queued_n"), excluded_landed=verdict)
    elif k.startswith("T17-A"):
        bad = "ok=0" in str(r.get("sessionA"))
        note = "QUARANTINED (session-A control failed)" if bad else \
               ("pre-gate harness version (probe not gated behind A-verify)" if "removetarget_status" not in r or r.get("probe_sender") == "NOT-FOUND" else "")
        add("T17-A delivery attempt after RemoveTarget", r["run"],
            completed="yes" if not bad else "no",
            sessionA=r.get("sessionA"), removetarget=r.get("removetarget_status"),
            probe_sender=r.get("probe_sender"), probe_landed=("yes" if r.get("probe_delivered") else "no"),
            note=note or ("request ACCEPTED, payload NOT delivered" if not bad else ""))
    elif k.startswith("T17-B v2"):
        if r.get("quarantined"):
            add("T17-B v2 same-port lifecycle (QUARANTINED)", r["run"], completed="no",
                note="harness bug: privileged port" if "privileged" in r["run"] else
                     "harness bug: senderB exited before drain (no hold); B-leg invalid → stale legs NOT TESTED")
        else:
            b_ok = "ok=3" in str(r.get("B_authorized"))
            add("T17-B v2 destroy+recreate SAME port; authorized-B verified first", r["run"],
                completed="yes" if b_ok else "no",
                A_delivery=r.get("A"), B_authorized=r.get("B_authorized"),
                existing_conn_after_teardown=r.get("existing_after_teardown"),
                stale_tinfo_landing=r.get("stale_tinfo"),
                stale_sender=r.get("stale_sender"),
                note="" if b_ok else "B control failed → stale conclusions NOT TESTED for this rep")
    elif k.startswith("T17-B"):
        failB = r.get("stale_probe_rx") == "NOT-FOUND"
        add("T17-B destroy+recreate; stale target-info reuse", r["run"],
            completed="no" if failB else "yes",
            sessionA=r.get("sessionA"), existing_conn_probe=r.get("existing_conn_probe"),
            stale_attempt=r.get("stale_sender") or ("receiver-B setup EACCES (privileged port)" if failB else ""),
            stale_landed=("yes" if r.get("stale_delivered") else "no"),
            tinfo_ab_differ=r.get("tinfo_ab_differ"),
            note="QUARANTINED (harness port bug)" if failB else "")
    elif k.startswith("T18"):
        steps = r.get("steps", [])
        add("T18 bounded concurrent targets + recovery", r["run"], completed="yes",
            steps="; ".join(f"{d}/{n} @ {s} targets" for s, ok, d, n, f in steps),
            recovery="ok" if "ok=3" in str(r.get("recovery")) else str(r.get("recovery")),
            overlap_windows=r.get("all_alive_sample_windows"))

hdr = ["case", "rep", "completed", "result"]
lines = ["| case | rep/run | completed | executed outcome |", "|---|---|---|---|"]
for x in rows:
    detail = " ".join(f"{k}={v}" for k, v in x.items() if k not in ("case", "rep", "completed"))
    lines.append(f"| {x['case']} | {x['rep']} | {x['completed']} | {detail} |")


def _disp_rows():
    rows = ["| run | status | detection/reason |", "|---|---|---|"]
    for d in sorted((HERE / "runs").glob("t1*")):
        if not d.is_dir(): continue
        n = d.name
        if "QUARANTINED" in n or "-contaminated-" in n:
            why = ("privileged port <1024 -> rdma_bind_addr EACCES" if "privileged" in n else
                   "sender exited before drain (missing hold); B-leg invalid" if "nohold" in n else
                   "timestamp collision between two campaigns; provenance unverifiable" if "collision" in n else
                   "stale readiness marker between reps; superseded by barrier fix" if "contaminated" in n else
                   "session-A control failed (ungated probe race)")
            rows.append(f"| {n} | QUARANTINED | {why} |")
        elif n.startswith("t17bv2-") and re.fullmatch(r"t17bv2-\d+-\d{6}", n):
            rows.append(f"| {n} | superseded | v2 triple (timestamp-collision provenance) re-executed as v3 |")
        else:
            rows.append(f"| {n} | counted | valid control or security run |")
    return "\n".join(rows)
disposition_table = _disp_rows()

prov = json.loads((HERE / "provenance-fabric.json").read_text())
doc = f"""# Fabric security campaign (V15 line) — MXL verbs/RoCEv2, T16–T18

**Starting reference:** V14 (archived intact under `v14-reference/`; local sources diffed identical,
`4e7dd448…`; the V14 banner text still says "V12-SHM" — a label error: both endpoints selected VERBS;
historical evidence NOT rewritten; corrected in the V15 harness.)

**Topology (accurate):** ONE host (DGX Spark, aarch64), ONE physically DAC-looped NIC pair
(enp1s0f0np0 192.168.100.1 <-> enP2p1s0f0np0 192.168.100.2, MTU config 9216, active_mtu 4096),
libfabric **verbs** provider, RC, RoCEv2. **This is not a two-host test.**

**SDK:** commit {prov['sdk_commit']}, build {prov['build']}. Compatibility patches (libfabric-1.21 feature-probe
in CMakeLists + fabric_wrapper.h, MemoryRegion field-presence guards) remain in force and are disclosed in
`evidence/sdk-compat-changes.patch`; the fabrics *security behavior* was not modified for any test.
Libraries actually loaded by live role processes: raw `/proc/<pid>/maps` snapshots with per-file SHA256 are
packaged at `runs/maps-evidence/maps.json` (libmxl f17409d1…, libmxl-fabrics c3bf1187…, libfabric 5430c104…).
The consolidated campaign execution log is packaged at `runs/campaign-t17bv2-logs.txt`.

## Run naming and disposition
Every campaign directory is listed with its status. Quarantined runs contributed no conclusions; each was
detected from its own logs or post-review reconstruction.

{disposition_table}

## Results matrix (one row per case × repetition actually executed)

{chr(10).join(lines)}

## Dimension report (execution vs conclusions, per spec §9)
- Experiment completed correctly: yes for the fresh authoritative runs; all invalid runs are listed in
  "Run naming and disposition" below with their detection mechanism. Several were detected only during
  post-campaign review, including the 10:22 T17-B v2 triple — its per-rep port releases (8501/8502/8503)
  and B-first ordering came from two campaigns that had overwritten each other's run directories via a
  second-granularity timestamp collision; those runs are now quarantined as UNVERIFIABLE and re-executed
  under PID-unique names.
- Functional control: single-process 3/3×3 reps; independent-process 3/3×3 reps; transfer-disabled shows 0/3 arrival.
- Peer connected / transfer accepted / target completion / grain published / exact payload returned: logged per leg above.
- Authorization expectation violated: **T16-C: yes (3/3)** — any peer holding the serialized TargetInfo is admitted
  and can write receiver grain storage; no peer-identity check exists to violate. T16-B: no — capability is required.
- Lifecycle expectation (T17-B v3, PID-unique runs, same node:port recreation, authorized-B verified first;
  the v2 triple at 10:22 is quarantined for directory-collision reasons and its apparent agreement is not relied on):
  **existing A-connection after target teardown: request locally accepted, 0/3 landed;
  stale serialized target info at the reused address:port: the recreated target ACCEPTS a new connection
  (AddTarget OK; verbs RC/rdma_cm connect OK), the request is queued with the sender kept alive and
  pumping through attribution — 0/3 grains land in the new receiver storage (B commits = 3, authorized
  only). Post-teardown existing-connection probe likewise executed (queued with live sender), 0/3 landed.
  Why the RMA produces no completion is NOT observed — no claim about write destination or provider rejection.**
  Earlier v1 runs that reported ECONNREFUSED did so only because the recreated target used a different port;
  superseded. T17-A: RemoveTarget blocks delivery (0/3 landed) although the local call ACCEPTS subsequent
  requests — acceptance ≠ delivery, recorded as separate dimensions. No SDK revocation mechanism exists;
  these are "stale target-information behavior after lifecycle change" results, not revocation-bypass results.
- Recovery succeeded: T18 post-teardown authorized transfer 3/3; 16-step peak RSS ~1.27 GB, ~1008 fds, 44 QPs;
  lifetimes verified overlapping (40/40 windows at full concurrency). NOTE (implementation limit of the executed
  runs): resources were SAMPLED during each step, but the budget gate was evaluated AFTER teardown and a leg
  delivery failure did not abort the step. The corrected t18.sh now checks budget and liveness every 0.25 s
  inside the monitor loop and treats any delivery failure as a stop condition (for future runs).
  The executed data therefore support "all sampled values were within budget" and "no budget breach occurred";
  they do not support "budget was enforced throughout".

## Receiver publication handling (disclosed, §4)
The SDK demo pattern (OpenGrain→CommitGrain at target after `mxlFabricsTargetReadGrain`) is used; the ingress
path writes validSlices from RMA immediate data (`setValidSlicesForGrain`, ProtocolIngressRMA.cpp:70), but for
this whole-grain verbs-RMA case the target-side `OpenGrain` **observed raw validSlices=0 / totalSlices=1080 in
every repetition** before any harness adjustment. The harness restores validSlices=totalSlices and RECORDS each
adjustment (raw metadata + commit status logged). Without the restoration, committed receiver grains are not
readable (MXL_ERR_OUT_OF_RANGE_TOO_LATE) — so the restoration is labeled a **harness adjustment**, with results
reported with and without it. Whether validSlices=0-after-ReadGrain is the intended contract could not be
established from headers/docs. Both observations (with-adjustment success, without-adjustment failure) are
preserved; the SDK contract remains UNRESOLVED, so this is documentation of a harness dependency, not a
security finding.

## Payload capture mapping
Sender payloads are deterministic ((idx*17+j*31+seed)&255, same generator in sender and verifier); the receiver
captures `rx-*.bin` compared byte-for-byte against that expectation serve as the comparison record (194 payload
captures on disk, SHA256-listed in the manifest; the t17bv2 collision-quarantined directories share capture
paths created by overlapping campaign executions and contribute no conclusions).
No separate sender-side dumps (identical by construction). All captures are SHA256-listed in the manifest.
"""
(HERE / "SUMMARY.md").write_text(doc)
json.dump({"provenance": prov, "rows": rows}, open(HERE / "results.json", "w"), indent=2)
print(f"SUMMARY.md + results.json: {len(rows)} rows")
