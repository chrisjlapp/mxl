#!/usr/bin/env bash
# T17-B v2: target destroy+recreate AT THE SAME node:service, with correct sequencing:
#   1. session A delivers + verifies (endpoints live)
#   2. destroy receiver A; wait until the port is actually released
#   3. recreate receiver B at the SAME address:port (fresh target, fresh serialized tinfoB)
#   4. AUTHORIZED B transfer verified BEFORE any stale attempt (proves B is functional)
#   5. existing A-connection probe (sender A still alive) AFTER A's teardown
#   6. stale-tinfo probe (fresh peer holding tinfoA) at the same address:port
# Attribution via unique indices and per-leg seeds.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BASE=/home/chlapp/projects/mxl-security-baseline
export LD_LIBRARY_PATH=/opt/libfabric121/lib:$BASE/build/lib:$BASE/build/lib/fabrics/ofi
REP=$1
RUN=$HERE/runs/t17bv2-$REP-$(date +%H%M%S)-$$   # unique: PID prevents parallel-campaign directory collision
while [ -e "$RUN.lock-wait" ] || ! mkdir -p "$RUN/rxA" "$RUN/rxB" 2>/dev/null; do sleep 0.3; done
[ -d "$RUN/rxA" ] && [ -d "$RUN/rxB" ] || { echo "SETUP-FAIL: capture dirs"; exit 2; }
FLOWID=$(python3 -c "import json;print(json.load(open('/tmp/mxl-target-flow.json'))['id'])")
SVC=$((8500+REP))                        # A and B use the SAME port; >=1024 (not privileged)
if [ "$SVC" -lt 1024 ]; then echo "PREFLIGHT-FAIL: port $SVC privileged (<1024) -> rdma_bind_addr EACCES"; exit 2; fi
if ss -tuln "( sport = :$SVC )" 2>/dev/null | grep -q ":$SVC"; then echo "PREFLIGHT-FAIL: port $SVC already in use"; exit 2; fi
BASEA=$((53711$((50+REP))0000))          # session A grains  +0..2, A-conn probe +3
BASEB=$((53711$((60+REP))0000))          # session B grains  +0..2
BASEX=$((53711$((70+REP))0000))          # stale-tinfo probe grain
BIDX_PROBE=$((BASEA+3))

RDOM_A=/dev/shm/mxl-v15mp-t17bv2a$REP-r; RDOM_B=/dev/shm/mxl-v15mp-t17bv2b$REP-r
SDOM_A=/dev/shm/mxl-v15mp-t17bv2a$REP-s; SDOM_B=/dev/shm/mxl-v15mp-t17bv2b$REP-s
SDOM_X=/dev/shm/mxl-v15mp-t17bv2x$REP-s
rm -rf $RDOM_A $RDOM_B $SDOM_A $SDOM_B $SDOM_X; mkdir -p $RDOM_A $RDOM_B $SDOM_A $SDOM_B $SDOM_X

# --- 1. session A ---
"$HERE/v15-roles" receiver v2a$REP "$RUN" $RDOM_A /tmp/mxl-target-flow.json "$RUN/tinfoA.json" "$SVC" > "$RUN/receiverA.log" 2>&1 &
RA=$!
for i in $(seq 1 200); do [ -e "$RUN/tinfoA.json.ready" ] && break; sleep 0.1; done
[ -e "$RUN/tinfoA.json.ready" ] || { echo "BARRIER-FAIL-A"; kill $RA 2>/dev/null; exit 3; }
"$HERE/v15-roles" sender v2sa$REP "$RUN" $SDOM_A /tmp/mxl-target-flow.json "$RUN/tinfoA.json" 192.168.100.1 "$BASEA" 3 61 "$RUN/holdA" --probe-file "$RUN/gateA" --no-remove > "$RUN/senderA.log" 2>&1 &
SA=$!
sleep 2
"$HERE/v15-roles" verify "$RUN/rxA" $RDOM_A "$FLOWID" "$BASEA" 3 61 > "$RUN/verifyA.log" 2>&1
ARC=$?; grep "^V RESULT" "$RUN/verifyA.log" | sed 's/^/A-DELIVERY: /'
[ $ARC -ne 0 ] && { echo "T17BV2-INVALID session-A failed"; touch "$RUN/holdA" "$RUN/gateA"; kill $SA $RA 2>/dev/null; exit 4; }

# --- 2. destroy A; wait for port release ---
kill -TERM $RA 2>/dev/null; wait $RA 2>/dev/null
for i in $(seq 1 100); do
  ss -tuln "( sport = :$SVC )" 2>/dev/null | grep -q ":$SVC" || break
  sleep 0.2
done
echo "port $SVC released after ${i:-0} polls"
rm -rf $RDOM_A

# --- 3. recreate B at the SAME address:port ---
"$HERE/v15-roles" receiver v2b$REP "$RUN" $RDOM_B /tmp/mxl-target-flow.json "$RUN/tinfoB.json" "$SVC" > "$RUN/receiverB.log" 2>&1 &
RB=$!
for i in $(seq 1 300); do [ -e "$RUN/tinfoB.json.ready" ] && break; kill -0 $RB 2>/dev/null || break; sleep 0.1; done
[ -e "$RUN/tinfoB.json.ready" ] || { echo "BARRIER-FAIL-B"; grep -m2 "FATAL\|bind" "$RUN/receiverB.log"; touch "$RUN/holdA" "$RUN/gateA"; kill $SA $RB 2>/dev/null; exit 3; }
sha256sum "$RUN/tinfoA.json" "$RUN/tinfoB.json" > "$RUN/tinfo-hashes.txt"
echo "tinfo A vs B:"; sed 's/^/  /' "$RUN/tinfo-hashes.txt"

# --- 4. authorized B transfer, verified BEFORE stale attempts ---
# NOTE: senderB MUST stay alive until after verification (QP teardown aborts
# undrained RDMA writes; see t17bv2 rep1-3 where a missing hold invalidated the leg).
"$HERE/v15-roles" sender v2sb$REP "$RUN" $SDOM_B /tmp/mxl-target-flow.json "$RUN/tinfoB.json" 192.168.100.1 "$BASEB" 3 62 "$RUN/holdB" > "$RUN/senderB.log" 2>&1 &
SB=$!
sleep 2
"$HERE/v15-roles" verify "$RUN/rxB" $RDOM_B "$FLOWID" "$BASEB" 3 62 > "$RUN/verifyB.log" 2>&1
BRC=$?; grep "^V RESULT" "$RUN/verifyB.log" | sed 's/^/B-AUTHORIZED: /'
touch "$RUN/holdB"; wait $SB 2>/dev/null
grep -cE "^R COMMIT" "$RUN/receiverB.log" | sed 's/^/B-receiver-commits-before-release: /'
if [ $BRC -ne 0 ]; then echo "T17BV2-INVALID authorized-B control failed; stale legs NOT TESTED"
  touch "$RUN/holdA" "$RUN/gateA"; kill $SA $RB 2>/dev/null; exit 4; fi

# --- 5. existing A-connection probe AFTER A teardown (same tinfo, connected QP from session A) ---
touch "$RUN/gateA"; sleep 3
grep -E "^S REMOVETARGET|^S QUEUED probe|^S PROBE-REJ|^S PROBE-ATT" "$RUN/senderA.log" | sed 's/^/EXISTING-CONN-AFTER-TEARDOWN: /'
"$HERE/v15-roles" verify "$RUN" $RDOM_B "$FLOWID" "$BIDX_PROBE" 1 61 > "$RUN/verifyExistingAfterTeardown.log" 2>&1
EC=$?; grep -E "^V RESULT|^V IDX" "$RUN/verifyExistingAfterTeardown.log" | sed 's/^/EXISTING-LEG: /'

# stale attempt: fresh sender, same tinfoA; waits on its own hold so the endpoint
# stays alive (and keeps pumping via stopfile path) through receiver-side attribution.
timeout 120 "$HERE/v15-roles" sender v2sx$REP "$RUN" $SDOM_X /tmp/mxl-target-flow.json "$RUN/tinfoA.json" 192.168.100.1 "$BASEX" 1 63 "$RUN/holdX" > "$RUN/stale.log" 2>&1 &
XS=$!
sleep 3
"$HERE/v15-roles" verify "$RUN" $RDOM_B "$FLOWID" "$BASEX" 1 63 > "$RUN/verifyStale.log" 2>&1
SRC=$?; grep -E "^V RESULT|^V IDX" "$RUN/verifyStale.log" | sed 's/^/STALE-RX: /'
touch "$RUN/holdX"; wait $XS 2>/dev/null
grep -E "^S RESULT|^S QUEUED|^S connected|^S ADDTARGET" "$RUN/stale.log" | sed 's/^/STALE-TINFO: /'

touch "$RUN/holdA"; wait $SA 2>/dev/null
kill -TERM $RB 2>/dev/null; wait $RB 2>/dev/null
rm -rf $RDOM_A $RDOM_B $SDOM_A $SDOM_B $SDOM_X
CC=$(grep -c "^R COMMIT" "$RUN/receiverB.log" 2>/dev/null)
echo "B-receiver-commits=$CC (3 = authorized only; +existing/+stale)"
echo "T17BV2-RESULT rep=$REP A_ok=yes B_ok=yes existing_landed=$([ $EC -eq 0 ] && echo yes || echo no) stale_landed=$([ $SRC -eq 0 ] && echo yes || echo no)"
