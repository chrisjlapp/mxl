/**
 * MXL V15 — single-process verbs/RoCEv2 fabric control (corrected labels).
 * Reproduces the V14 milestone (archive hash 4e7dd448...) with honest naming:
 * this harness is VERBS, not shm. V14's "V12-SHM" banner is historical evidence
 * and is NOT rewritten; the discrepancy is documented in findings.md.
 *
 * Topology (all in ONE process, looped physical NIC):
 *   sender domain   /dev/shm/<tag>-s   (flow writer; initiator attaches reader)
 *   receiver domain /dev/shm/<tag>-r   (flow writer owned by FABRICS TARGET)
 *
 * Delivery success requires: 3 exact-index receiver SDK reads, grainSize equal
 * to independently established capacity, complete slice counts, nonzero and
 * byte-exact full payloads. Target startup / queue acceptance / progress OK
 * are recorded but are NEVER sufficient for a delivery verdict.
 *
 * --no-transfer: negative control. Full connection establishment runs; the
 * payload RMA is never requested; receiver storage stays fresh. Receiver reads
 * must NOT return the expected payload.
 *
 * Usage: v15-control <tag> <outdir> [--no-transfer]
 */
#define _GNU_SOURCE 1
#define _DEFAULT_SOURCE 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <mxl/mxl.h>
#include <mxl/flow.h>
#include <mxl/fabrics.h>

#define NUM_GRAINS 3
#define FLOW_PATH "/tmp/mxl-target-flow.json"

static uint64_t g_baseIdx = 0;
static uint8_t payload_byte(uint64_t idx, uint32_t j) {
    return (uint8_t)((idx * 17 + j * 31 + 42) & 255);
}
static int extract_flow_id(const char *fd, char *buf, size_t sz) {
    const char *p = strstr(fd, "\"id\":"); if (!p) return -1;
    p += 5; while (*p == ' ') p++; if (*p != '"') return -1; p++;
    const char *e = strchr(p, '"'); if (!e) return -1;
    size_t len = (size_t)(e - p); if (len >= sz) len = sz - 1;
    memcpy(buf, p, len); buf[len] = '\0'; return 0;
}
static int load_flow_def(const char *path, char **out) {
    FILE *f = fopen(path, "r"); if (!f) return -1;
    fseek(f, 0, SEEK_END); long sz = ftell(f); rewind(f);
    *out = malloc((size_t)sz + 1); if (!*out) { fclose(f); return -1; }
    size_t r = fread(*out, 1, (size_t)sz, f); (*out)[r] = '\0'; fclose(f);
    return 0;
}
static void dump_payload(const char *dir, const char *what, uint64_t idx,
                         const uint8_t *pl, uint32_t n) {
    char path[512];
    snprintf(path, sizeof(path), "%s/%s-%llu.bin", dir, what, (unsigned long long)idx);
    FILE *f = fopen(path, "wb");
    if (f) { fwrite(pl, 1, n, f); fclose(f); }
    fprintf(stderr, "DUMP %s idx=%llu bytes=%u path=%s\n", what,
            (unsigned long long)idx, n, path);
}

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: %s <tag> <outdir> [--no-transfer]\n", argv[0]); return 2; }
    const char *tag = argv[1];
    const char *outdir = argv[2];
    int no_transfer = (argc > 3 && !strcmp(argv[3], "--no-transfer"));
    int no_adjust = 0;
    for (int i = 1; i < argc; i++) if (!strcmp(argv[i], "--no-adjust")) no_adjust = 1;
    char SND_DOMAIN[256], RCV_DOMAIN[256];
    snprintf(SND_DOMAIN, sizeof(SND_DOMAIN), "/dev/shm/mxl-v15-%s-s", tag);
    snprintf(RCV_DOMAIN, sizeof(RCV_DOMAIN), "/dev/shm/mxl-v15-%s-r", tag);
    fprintf(stderr, "=== MXL V15 verbs/RoCEv2 control (single process) tag=%s no_transfer=%d ===\n",
            tag, no_transfer);
    fprintf(stderr, "TOPOLOGY: same host, physically looped NIC pair 192.168.100.1(sender/initiator)<->192.168.100.2(receiver/target), provider=verbs, RC. NOT a two-host test.\n");

    char rmcmd[600];
    snprintf(rmcmd, sizeof(rmcmd), "rm -rf %s %s", SND_DOMAIN, RCV_DOMAIN);
    if (system(rmcmd)) { /* fresh disposable domains; negative control relies on fresh receiver storage */ }
    mkdir(SND_DOMAIN, 0775); mkdir(RCV_DOMAIN, 0775);

    char *flowDef = NULL;
    if (load_flow_def(FLOW_PATH, &flowDef)) { fprintf(stderr, "FATAL no flow def\n"); return 2; }
    char flowId[64];
    if (extract_flow_id(flowDef, flowId, sizeof(flowId))) { fprintf(stderr, "FATAL flow id\n"); return 2; }
    fprintf(stderr, "flow: %s\n", flowId);

    mxlInstance s_inst = mxlCreateInstance(SND_DOMAIN, "");
    mxlInstance r_inst = mxlCreateInstance(RCV_DOMAIN, "");
    if (!s_inst || !r_inst) { fprintf(stderr, "FATAL instance creation\n"); return 2; }

    mxlFlowWriter sw = NULL, rw = NULL;
    mxlFlowConfigInfo scfg = {0}, rcfg = {0};
    bool created = false;
    mxlStatus st = mxlCreateFlowWriter(s_inst, flowDef, NULL, &sw, &scfg, &created);
    if (st) { fprintf(stderr, "FATAL sender writer %d\n", (int)st); return 2; }
    fprintf(stderr, "sender flow created=%d ring=%u\n", created, scfg.discrete.grainCount);
    created = false;
    st = mxlCreateFlowWriter(r_inst, flowDef, NULL, &rw, &rcfg, &created);
    if (st) { fprintf(stderr, "FATAL receiver writer %d\n", (int)st); return 2; }

    mxlFlowReader sr = NULL, rr = NULL;
    st = mxlCreateFlowReader(s_inst, flowId, "", &sr);
    if (st) { fprintf(stderr, "FATAL sender reader %d\n", (int)st); return 2; }

    mxlFabricsInstance rfi = NULL, sfi = NULL;
    st = mxlFabricsCreateInstance(r_inst, NULL, &rfi);
    if (st) { fprintf(stderr, "FATAL fabrics(r) %d\n", (int)st); return 2; }
    st = mxlFabricsCreateInstance(s_inst, NULL, &sfi);
    if (st) { fprintf(stderr, "FATAL fabrics(s) %d\n", (int)st); return 2; }

    mxlFabricsTarget tgt = NULL;
    st = mxlFabricsCreateTarget(rfi, &tgt);
    if (st) { fprintf(stderr, "FATAL target create %d\n", (int)st); return 2; }

    mxlFabricsTargetConfig tc = {0};
    tc.version = MXL_FABRICS_API_VERSION;
    tc.interface.version = MXL_FABRICS_API_VERSION;
    tc.interface.provider = MXL_FABRICS_PROVIDER_VERBS;
    tc.interface.caps.version = MXL_FABRICS_API_VERSION;
    tc.interface.caps.flags = MXL_FABRICS_IFACE_CAP_BLOCKING_OPERATIONS |
                              MXL_FABRICS_IFACE_CAP_REMOTE_WRITE;
    tc.interface.address.node = "192.168.100.2";
    tc.interface.address.service = "7001";
    tc.writer = rw;
    mxlFabricsTargetInfo tinfo = NULL;
    st = mxlFabricsTargetSetup(tgt, &tc, NULL, &tinfo);
    if (st) { fprintf(stderr, "FATAL target setup %d\n", (int)st); return 2; }
    fprintf(stderr, "target setup OK (node=192.168.100.2 service=7001 verbs)\n");

    mxlFabricsInitiator ini = NULL;
    st = mxlFabricsCreateInitiator(sfi, &ini);
    if (st) { fprintf(stderr, "FATAL init create %d\n", (int)st); return 2; }
    mxlFabricsInitiatorConfig ic = {0};
    ic.version = MXL_FABRICS_API_VERSION;
    ic.interface.version = MXL_FABRICS_API_VERSION;
    ic.interface.provider = MXL_FABRICS_PROVIDER_VERBS;
    ic.interface.caps.version = MXL_FABRICS_API_VERSION;
    ic.interface.caps.flags = MXL_FABRICS_IFACE_CAP_BLOCKING_OPERATIONS |
                              MXL_FABRICS_IFACE_CAP_REMOTE_WRITE;
    ic.interface.address.node = "192.168.100.1";   /* local bind; no service (V14 lesson) */
    ic.interface.address.service = NULL;
    ic.reader = sr;
    st = mxlFabricsInitiatorSetup(ini, &ic, NULL);
    if (st) { fprintf(stderr, "FATAL initiator setup %d\n", (int)st); return 2; }
    st = mxlFabricsInitiatorAddTarget(ini, tinfo);
    if (st) { fprintf(stderr, "FATAL add target %d\n", (int)st); return 2; }
    fprintf(stderr, "initiator setup OK, target added\n");

    /* ---- publish 3 deterministic grains on sender ---- */
    int now_s = (int)time(NULL);
    g_baseIdx = (uint64_t)now_s * 30000 / 1001;
    uint32_t sliceCount[NUM_GRAINS] = {0};
    uint32_t grainSizeVal = 0;
    for (int i = 0; i < NUM_GRAINS; i++) {
        uint64_t idx = g_baseIdx + i;
        mxlGrainInfo gi = {0};
        gi.version = 2; gi.size = sizeof(mxlGrainInfo); gi.index = idx;
        uint8_t *payload = NULL;
        st = mxlFlowWriterOpenGrain(sw, idx, &gi, &payload);
        if (st) { fprintf(stderr, "FATAL OpenGrain %d\n", (int)st); return 2; }
        if (gi.grainSize == 0 || gi.totalSlices == 0) { fprintf(stderr, "FATAL zero metadata\n"); return 2; }
        grainSizeVal = gi.grainSize;
        sliceCount[i] = gi.totalSlices;
        for (uint32_t j = 0; j < gi.grainSize; j++) payload[j] = payload_byte(idx, j);
        gi.validSlices = gi.totalSlices;
        st = mxlFlowWriterCommitGrain(sw, &gi);
        if (st) { fprintf(stderr, "FATAL CommitGrain %d\n", (int)st); return 2; }
        fprintf(stderr, "SENT idx=%llu grainSize=%u slices=%u\n", (unsigned long long)idx,
                gi.grainSize, gi.totalSlices);
    }

    /* ---- connect: interleaved non-blocking pump ---- */
    int connected = 0;
    for (int i = 0; i < 4000 && !connected; i++) {
        uint64_t gidx = 0;
        mxlFabricsTargetReadGrainNonBlocking(tgt, &gidx);
        mxlStatus ps = mxlFabricsInitiatorMakeProgressNonBlocking(ini);
        if (ps == MXL_STATUS_OK) connected = 1;
        else if (ps != MXL_ERR_NOT_READY) { fprintf(stderr, "progress error %d\n", (int)ps); break; }
        usleep(1000);
    }
    fprintf(stderr, "connected=%d\n", connected);
    if (!connected) { fprintf(stderr, "FATAL connection failed\n"); return 2; }

    /* ---- transfer loop (or negative control: skip payload RMA only) ---- */
    int queued = 0, tcommitted = 0, pump = 0;
    int adj_made[NUM_GRAINS] = {0};   /* did harness have to restore validSlices? */
    uint32_t rawVS[NUM_GRAINS] = {0}, rawTS[NUM_GRAINS] = {0};
    int commitStatus[NUM_GRAINS] = {-1,-1,-1};
    while (pump++ < 20000 && (queued < NUM_GRAINS || tcommitted < NUM_GRAINS)) {
        uint64_t gidx = 0;
        mxlStatus rs = mxlFabricsTargetReadGrainNonBlocking(tgt, &gidx);
        if (rs == MXL_STATUS_OK) {
            int slot = -1;
            for (int i = 0; i < NUM_GRAINS; i++) if (gidx == g_baseIdx + i) slot = i;
            mxlGrainInfo tgi = {0};
            tgi.version = 2; tgi.size = sizeof(mxlGrainInfo);
            uint8_t *tp = NULL;
            st = mxlFlowWriterOpenGrain(rw, gidx, &tgi, &tp);
            if (st == MXL_STATUS_OK) {
                if (slot >= 0) { rawVS[slot] = tgi.validSlices; rawTS[slot] = tgi.totalSlices; }
                /* Publication follows the SDK demo (fabrics-demo.cpp:819-835): OpenGrain then
                   CommitGrain with SDK-returned metadata, no payload copy. The validSlices
                   restoration below is a disclosed harness adjustment; it is RECORDED, not hidden. */
                if (tgi.validSlices == 0 && tgi.totalSlices > 0 && !no_adjust) {
                    tgi.validSlices = tgi.totalSlices;
                    if (slot >= 0) adj_made[slot] = 1;
                    fprintf(stderr, "ADJUST idx=%llu validSlices 0->%u (totalSlices=%u)\n",
                            (unsigned long long)gidx, tgi.validSlices, tgi.totalSlices);
                }
                st = mxlFlowWriterCommitGrain(rw, &tgi);
                if (slot >= 0) commitStatus[slot] = (int)st;
                if (st == MXL_STATUS_OK) {
                    tcommitted++;
                    fprintf(stderr, "TARGET-COMMIT idx=%llu rawVS=%u rawTS=%u\n",
                            (unsigned long long)gidx, rawVS[slot < 0 ? 0 : slot],
                            rawTS[slot < 0 ? 0 : slot]);
                }
            }
        } else if (rs != MXL_ERR_NOT_READY && rs != MXL_ERR_TIMEOUT) {
            fprintf(stderr, "TargetReadGrain err %d\n", (int)rs);
        }
        mxlFabricsInitiatorMakeProgressNonBlocking(ini);
        if (!no_transfer && queued < NUM_GRAINS) {
            st = mxlFabricsInitiatorTransferGrain(ini, g_baseIdx + queued, 0, sliceCount[queued]);
            if (st == MXL_STATUS_OK) { queued++; fprintf(stderr, "QUEUED grain %d idx=%llu slices=%u\n",
                                  queued, (unsigned long long)(g_baseIdx + queued - 1), sliceCount[queued-1]); }
            else if (st != MXL_ERR_NOT_READY && st != MXL_ERR_TIMEOUT && st != (mxlStatus)11 /*EAGAIN*/) {
                fprintf(stderr, "TransferGrain err %d\n", (int)st);
            }
        }
        if (no_transfer && pump > 500) break;   /* 0.5 s of connection-only pumping */
        usleep(200);
    }
    fprintf(stderr, "phase: queued=%d target_committed=%d pumps=%d (progress calls executed)\n",
            queued, tcommitted, pump);

    /* ---- receiver verification through SDK at exact sender indices ---- */
    st = mxlCreateFlowReader(r_inst, flowId, "", &rr);
    if (st) { fprintf(stderr, "FATAL receiver reader %d\n", (int)st); return 2; }
    int ok = 0, errs = 0, bad = 0;
    for (int i = 0; i < NUM_GRAINS; i++) {
        uint64_t idx = g_baseIdx + i;
        mxlGrainInfo rgi = {0};
        rgi.version = 2; rgi.size = sizeof(mxlGrainInfo);
        uint8_t *rp = NULL;
        st = mxlFlowReaderGetGrain(rr, idx, 2000000000ULL, &rgi, &rp);
        if (st != MXL_STATUS_OK) {
            errs++;
            fprintf(stderr, "RX idx=%llu read_status=%d\n", (unsigned long long)idx, (int)st);
            if (no_transfer) fprintf(stderr, "NEG-CONTROL-READ idx=%llu no-payload-as-expected\n",
                                     (unsigned long long)idx);
            continue;
        }
        if (!rp || rgi.grainSize == 0) { errs++; fprintf(stderr, "RX idx=%llu null/zero\n", (unsigned long long)idx); continue; }
        if (rgi.grainSize != grainSizeVal) {   /* independently established capacity */
            errs++; fprintf(stderr, "RX idx=%llu UNEXPECTED-SIZE %u != %u\n",
                    (unsigned long long)idx, rgi.grainSize, grainSizeVal); continue;
        }
        dump_payload(outdir, "rx", idx, rp, rgi.grainSize);
        int mism = 0, allzero = 1;
        for (uint32_t j = 0; j < rgi.grainSize; j++) {
            if (rp[j] != payload_byte(idx, j)) mism++;
            if (rp[j]) allzero = 0;
        }
        int slcok = (rgi.validSlices == rgi.totalSlices && rgi.totalSlices == sliceCount[i]);
        fprintf(stderr, "RX idx=%llu grainSize=%u slices=%u/%u mismatches=%d allzero=%d slices_ok=%d\n",
                (unsigned long long)idx, rgi.grainSize, rgi.validSlices, rgi.totalSlices,
                mism, allzero, slcok);
        if (no_transfer) {
            /* negative control: any expected payload byte appearing is a FAIL */
            if (mism == (int)rgi.grainSize || allzero) ok++;   /* not the payload */
            else { fprintf(stderr, "NEG-CONTROL-LEAK idx=%llu\n", (unsigned long long)idx); bad++; }
        }
        else if (mism == 0 && !allzero && slcok) ok++;
        else bad++;
    }
    if (no_transfer)
        fprintf(stderr, "=== NEGATIVE CONTROL VERDICT: no-arrival=%d/%d (leaks=%d errs=%d) ===\n",
                ok, NUM_GRAINS, bad, errs);
    else
        fprintf(stderr, "=== VERDICT: delivery %d/%d (err=%d bad=%d) ===\n", ok, NUM_GRAINS, errs, bad);

    fprintf(stderr, "PUBLICATION-DISCIPLINE idx0 raw_validSlices=%u raw_totalSlices=%u adjusted=%d commit_status=%d\n",
            rawVS[0], rawTS[0], adj_made[0], commitStatus[0]);
    fprintf(stderr, "PUBLICATION-DISCIPLINE idx1 raw_validSlices=%u raw_totalSlices=%u adjusted=%d commit_status=%d\n",
            rawVS[1], rawTS[1], adj_made[1], commitStatus[1]);
    fprintf(stderr, "PUBLICATION-DISCIPLINE idx2 raw_validSlices=%u raw_totalSlices=%u adjusted=%d commit_status=%d\n",
            rawVS[2], rawTS[2], adj_made[2], commitStatus[2]);

    { const char *h = getenv("MXL_HOLD"); if (h) { fprintf(stderr, "holding %ss\n", h); sleep(atoi(h)); } }

    mxlReleaseFlowReader(r_inst, rr);
    mxlReleaseFlowReader(s_inst, sr);
    if (tinfo) mxlFabricsFreeTargetInfo(tinfo);
    mxlFabricsDestroyInitiator(sfi, ini);
    mxlFabricsDestroyTarget(rfi, tgt);
    mxlFabricsDestroyInstance(sfi);
    mxlFabricsDestroyInstance(rfi);
    mxlReleaseFlowWriter(r_inst, rw);
    mxlReleaseFlowWriter(s_inst, sw);
    mxlDestroyInstance(s_inst);
    mxlDestroyInstance(r_inst);
    free(flowDef);
    int pass = no_transfer ? (bad == 0)                    /* no expected payload arrived */
                           : (ok == NUM_GRAINS && errs == 0 && bad == 0);
    fprintf(stderr, "EXIT %d\n", pass ? 0 : 1);
    return pass ? 0 : 1;
}
