#!/usr/bin/env bash
# Remaining T17/T16 reps campaign (bounded, sequential; independent flow UUIDs per run).
set -uo pipefail
cd "$(dirname "$0")"
{
echo "### T17-A rep1 (RemoveTarget, gated) $(date -Is)"
timeout 300 bash t17a.sh 1 2>&1 | grep -E "VERIFY|GATE|REMOVETARGET|QUEUED probe|PROBE-|PROBE:|commits|RESULT|INVALID|FAIL"
echo "### T17-A rep2 $(date -Is)"
timeout 300 bash t17a.sh 2 2>&1 | grep -E "VERIFY|GATE|REMOVETARGET|QUEUED probe|PROBE-|PROBE:|commits|RESULT|INVALID|FAIL"
echo "### T17-A rep3 $(date -Is)"
timeout 300 bash t17a.sh 3 2>&1 | grep -E "VERIFY|GATE|REMOVETARGET|QUEUED probe|PROBE-|PROBE:|commits|RESULT|INVALID|FAIL"
echo "### T17-B rep1 $(date -Is)"
timeout 400 bash t17b.sh 1 2>&1 | grep -E "VERIFY|EXISTING|STALE|hashes|delivered|RESULT|INVALID|FAIL|bound"
echo "### T17-B rep2 $(date -Is)"
timeout 400 bash t17b.sh 2 2>&1 | grep -E "VERIFY|EXISTING|STALE|hashes|delivered|RESULT|INVALID|FAIL|bound"
echo "### T17-B rep3 $(date -Is)"
timeout 400 bash t17b.sh 3 2>&1 | grep -E "VERIFY|EXISTING|STALE|hashes|delivered|RESULT|INVALID|FAIL|bound"
echo "### T16-C rep2 $(date -Is)"
timeout 500 bash t16c.sh 2 2>&1 | grep -E "==|rc=|RESULT|EXCL-RX|receiver-commits|T16C"
echo "### T16-C rep3 $(date -Is)"
timeout 500 bash t16c.sh 3 2>&1 | grep -E "==|rc=|RESULT|EXCL-RX|receiver-commits|T16C"
echo "### T16-B rep2 $(date -Is)"
timeout 300 bash t16b.sh 2 2>&1 | grep -E "==|rc=|RESULT|NO-TARGET|TINFO|IDX|commits|T16B"
echo "### T16-B rep3 $(date -Is)"
timeout 300 bash t16b.sh 3 2>&1 | grep -E "==|rc=|RESULT|NO-TARGET|TINFO|IDX|commits|T16B"
echo "CAMPAIGN-DONE $(date -Is)"
} 2>&1
